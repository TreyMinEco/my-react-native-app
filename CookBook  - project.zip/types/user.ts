import { Recipe } from './recipe';

export type UserPreferences = {
  theme: 'light' | 'dark' | 'system';
  language: string;
  dietaryPreferences: string[];
  allergies: string[];
  dislikedIngredients: string[];
  cookingSkillLevel: 'beginner' | 'intermediate' | 'advanced';
  measurementSystem: 'metric' | 'imperial';
  notificationsEnabled: boolean;
  pushNotifications: {
    newRecipes: boolean;
    mealReminders: boolean;
    tips: boolean;
  };
};

export type ShoppingListItem = {
  id: string;
  name: string;
  amount?: string;
  unit?: string;
  recipeId?: string;
  checked?: boolean;
  category?: string;
};

export type MealPlanDay = {
  date: string;
  breakfast?: string[];
  lunch?: string[];
  dinner?: string[];
  snacks?: string[];
};

export type MealPlan = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  days: MealPlanDay[];
};

export type UserProfile = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  preferences: UserPreferences;
  favorites: string[]; // Recipe IDs
  history: {
    recipeId: string;
    viewedAt: string;
  }[];
  createdRecipes: string[]; // Recipe IDs
  shoppingList: ShoppingListItem[];
  mealPlans: MealPlan[];
};