export type Ingredient = {
    id: string;
    name: string;
    amount: number;
    unit: string;
    optional?: boolean;
  };
  
  export type Instruction = {
    id: string;
    step: number;
    description: string;
    imageUrl?: string;
    videoUrl?: string;
    timers?: number[]; // Time in seconds
  };
  
  export type RecipeReview = {
    id: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    rating: number;
    comment: string;
    date: string;
    images?: string[];
  };
  
  export type RecipeDifficulty = 'easy' | 'medium' | 'hard';
  
  export type DietaryTag = 
    | 'vegetarian' 
    | 'vegan' 
    | 'gluten-free' 
    | 'dairy-free' 
    | 'keto' 
    | 'paleo' 
    | 'low-carb' 
    | 'low-fat' 
    | 'high-protein' 
    | 'nut-free' 
    | 'soy-free' 
    | 'diabetic-friendly';
  
  export type MealType = 
    | 'breakfast' 
    | 'lunch' 
    | 'dinner' 
    | 'snack' 
    | 'dessert' 
    | 'drink' 
    | 'appetizer' 
    | 'side dish' 
    | 'main course' 
    | 'salad' 
    | 'soup' 
    | 'sauce';
  
  export type Cuisine = 
    | 'italian' 
    | 'mexican' 
    | 'american' 
    | 'japanese' 
    | 'chinese' 
    | 'indian' 
    | 'french' 
    | 'thai' 
    | 'spanish' 
    | 'greek' 
    | 'mediterranean' 
    | 'middle eastern' 
    | 'korean' 
    | 'vietnamese' 
    | 'ukrainian' 
    | 'german' 
    | 'british';
  
  export type NutritionInfo = {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    sugar?: number;
    fiber?: number;
    sodium?: number;
  };
  
  export interface Recipe {
    id: string;
    title: string;
    description: string;
    imageUrl: string;
    videoUrl?: string;
    prepTime: number; // In minutes
    cookTime: number; // In minutes
    totalTime: number; // In minutes
    servings: number;
    difficulty: RecipeDifficulty;
    ingredients: Ingredient[];
    instructions: Instruction[];
    cuisine: Cuisine;
    mealType: MealType[];
    dietaryTags: DietaryTag[];
    nutritionInfo: NutritionInfo;
    authorId?: string;
    authorName: string;
    authorAvatar?: string;
    datePublished: string;
    dateUpdated?: string;
    rating: number;
    reviewCount: number;
    reviews?: RecipeReview[];
    isFeatured?: boolean;
    isVerified?: boolean;
    relatedRecipes?: string[]; // Array of recipe IDs
  }
  
  export type RecipeFilters = {
    query?: string;
    ingredients?: string[];
    cuisine?: Cuisine[];
    mealType?: MealType[];
    dietaryTags?: DietaryTag[];
    maxPrepTime?: number;
    maxCookTime?: number;
    maxCalories?: number;
    difficulty?: RecipeDifficulty[];
  };
  
  export type ShoppingListItem = {
    id: string;
    name: string;
    amount: number;
    unit: string;
    recipeId: string;
    recipeName: string;
    checked: boolean;
  };
  
  export type MealPlanDay = {
    date: string;
    breakfast?: string[]; // Recipe IDs
    lunch?: string[];
    dinner?: string[];
    snacks?: string[];
  };
  
  export type MealPlan = {
    id: string;
    name: string;
    days: MealPlanDay[];
  };