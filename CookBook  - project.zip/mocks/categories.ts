import { MealType, Cuisine, DietaryTag } from '@/types/recipe';

export const mealTypes: { id: MealType; name: string; icon: string }[] = [
  { id: 'breakfast', name: 'Breakfast', icon: 'coffee' },
  { id: 'lunch', name: 'Lunch', icon: 'utensils' },
  { id: 'dinner', name: 'Dinner', icon: 'utensils-crossed' },
  { id: 'snack', name: 'Snacks', icon: 'cookie' },
  { id: 'dessert', name: 'Desserts', icon: 'cake-slice' },
  { id: 'drink', name: 'Drinks', icon: 'wine' },
  { id: 'appetizer', name: 'Appetizers', icon: 'salad' },
  { id: 'side dish', name: 'Side Dishes', icon: 'bowl-food' },
  { id: 'main course', name: 'Main Courses', icon: 'chef-hat' },
  { id: 'salad', name: 'Salads', icon: 'salad' },
  { id: 'soup', name: 'Soups', icon: 'soup' },
  { id: 'sauce', name: 'Sauces', icon: 'flask-conical' },
];

export const cuisines: { id: Cuisine; name: string; flag?: string }[] = [
  { id: 'italian', name: 'Italian', flag: '🇮🇹' },
  { id: 'mexican', name: 'Mexican', flag: '🇲🇽' },
  { id: 'american', name: 'American', flag: '🇺🇸' },
  { id: 'japanese', name: 'Japanese', flag: '🇯🇵' },
  { id: 'chinese', name: 'Chinese', flag: '🇨🇳' },
  { id: 'indian', name: 'Indian', flag: '🇮🇳' },
  { id: 'french', name: 'French', flag: '🇫🇷' },
  { id: 'thai', name: 'Thai', flag: '🇹🇭' },
  { id: 'spanish', name: 'Spanish', flag: '🇪🇸' },
  { id: 'greek', name: 'Greek', flag: '🇬🇷' },
  { id: 'mediterranean', name: 'Mediterranean' },
  { id: 'middle eastern', name: 'Middle Eastern' },
  { id: 'korean', name: 'Korean', flag: '🇰🇷' },
  { id: 'vietnamese', name: 'Vietnamese', flag: '🇻🇳' },
  { id: 'ukrainian', name: 'Ukrainian', flag: '🇺🇦' },
  { id: 'german', name: 'German', flag: '🇩🇪' },
  { id: 'british', name: 'British', flag: '🇬🇧' },
];

export const dietaryTags: { id: DietaryTag; name: string; icon: string }[] = [
  { id: 'vegetarian', name: 'Vegetarian', icon: 'leaf' },
  { id: 'vegan', name: 'Vegan', icon: 'vegan' },
  { id: 'gluten-free', name: 'Gluten-Free', icon: 'wheat-off' },
  { id: 'dairy-free', name: 'Dairy-Free', icon: 'milk-off' },
  { id: 'keto', name: 'Keto', icon: 'beef' },
  { id: 'paleo', name: 'Paleo', icon: 'drumstick' },
  { id: 'low-carb', name: 'Low-Carb', icon: 'scale' },
  { id: 'low-fat', name: 'Low-Fat', icon: 'scale-3d' },
  { id: 'high-protein', name: 'High-Protein', icon: 'egg' },
  { id: 'nut-free', name: 'Nut-Free', icon: 'ban' },
  { id: 'soy-free', name: 'Soy-Free', icon: 'ban' },
  { id: 'diabetic-friendly', name: 'Diabetic-Friendly', icon: 'activity' },
];

export const cookingTimes = [
  { id: '15', name: 'Under 15 minutes' },
  { id: '30', name: 'Under 30 minutes' },
  { id: '45', name: 'Under 45 minutes' },
  { id: '60', name: 'Under 1 hour' },
  { id: '120', name: 'Under 2 hours' },
];

export const difficulties = [
  { id: 'easy', name: 'Easy' },
  { id: 'medium', name: 'Medium' },
  { id: 'hard', name: 'Hard' },
];

// Export a combined categories object for convenience
export const categories = {
  mealTypes,
  cuisines,
  dietaryTags,
  cookingTimes,
  difficulties
};