import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MealPlanDay as MealPlanDayType } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Plus } from 'lucide-react-native';
import { useRecipeStore } from '@/store/recipe-store';

interface MealPlanDayProps {
  day: MealPlanDayType;
  onAddMeal: (mealType: string) => void;
  onRemoveMeal: (mealType: string, recipeId: string) => void;
  onViewRecipe: (recipeId: string) => void;
}

export const MealPlanDay: React.FC<MealPlanDayProps> = ({
  day,
  onAddMeal,
  onRemoveMeal,
  onViewRecipe,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const getRecipeById = useRecipeStore(state => state.getRecipeById);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
    }
  };

  const mealTypes = [
    { id: 'breakfast', label: 'Breakfast' },
    { id: 'lunch', label: 'Lunch' },
    { id: 'dinner', label: 'Dinner' },
    { id: 'snacks', label: 'Snacks' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: themeColors.card }]}>
      <Text style={[styles.date, { color: themeColors.text }]}>
        {formatDate(day.date)}
      </Text>
      
      {mealTypes.map((mealType) => (
        <View key={mealType.id} style={styles.mealSection}>
          <Text style={[styles.mealTypeLabel, { color: themeColors.subtext }]}>
            {mealType.label}
          </Text>
          
          {day[mealType.id as keyof typeof day] && 
           (day[mealType.id as keyof typeof day] as string[])?.length > 0 ? (
            (day[mealType.id as keyof typeof day] as string[]).map((recipeId) => {
              const recipe = getRecipeById(recipeId);
              return recipe ? (
                <View key={recipeId} style={styles.recipeItem}>
                  <TouchableOpacity 
                    style={styles.recipeName}
                    onPress={() => onViewRecipe(recipeId)}
                  >
                    <Text 
                      style={[styles.recipeNameText, { color: themeColors.text }]}
                      numberOfLines={1}
                    >
                      {recipe.title}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    onPress={() => onRemoveMeal(mealType.id, recipeId)}
                    hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
                  >
                    <Text style={{ color: themeColors.error }}>✕</Text>
                  </TouchableOpacity>
                </View>
              ) : null;
            })
          ) : (
            <TouchableOpacity 
              style={[
                styles.addMealButton, 
                { borderColor: themeColors.border }
              ]}
              onPress={() => onAddMeal(mealType.id)}
            >
              <Plus size={16} color={themeColors.primary} />
              <Text style={[styles.addMealText, { color: themeColors.primary }]}>
                Add {mealType.label}
              </Text>
            </TouchableOpacity>
          )}
          
          {day[mealType.id as keyof typeof day] && 
           (day[mealType.id as keyof typeof day] as string[])?.length > 0 && (
            <TouchableOpacity 
              style={styles.addAnotherButton}
              onPress={() => onAddMeal(mealType.id)}
            >
              <Text style={[styles.addAnotherText, { color: themeColors.primary }]}>
                + Add another
              </Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  date: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  mealSection: {
    marginBottom: 16,
  },
  mealTypeLabel: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 8,
  },
  recipeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  recipeName: {
    flex: 1,
    marginRight: 8,
  },
  recipeNameText: {
    fontSize: 16,
  },
  addMealButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderRadius: 8,
    borderStyle: 'dashed',
    alignSelf: 'flex-start',
    gap: 6,
  },
  addMealText: {
    fontSize: 14,
    fontWeight: '500',
  },
  addAnotherButton: {
    marginTop: 4,
  },
  addAnotherText: {
    fontSize: 14,
  },
});