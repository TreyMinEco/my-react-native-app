import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  TextInputProps,
  ViewStyle,
  TouchableOpacity,
} from 'react-native';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Eye, EyeOff } from 'lucide-react-native';
import layout, { normalize, responsiveFontSize } from '@/constants/layout';

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  containerStyle?: ViewStyle;
  isPassword?: boolean;
  onClear?: () => void;
  showClearButton?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  leftIcon,
  rightIcon,
  containerStyle,
  isPassword = false,
  onClear,
  showClearButton = false,
  ...rest
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [showPassword, setShowPassword] = useState(!isPassword);
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  const handleFocus = () => {
    setIsFocused(true);
    if (rest.onFocus) {
      rest.onFocus(new Event('focus') as any);
    }
  };

  const handleBlur = () => {
    setIsFocused(false);
    if (rest.onBlur) {
      rest.onBlur(new Event('blur') as any);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const passwordIcon = showPassword ? (
    <TouchableOpacity onPress={togglePasswordVisibility} style={styles.iconContainer}>
      <EyeOff size={normalize(20)} color={themeColors.subtext} />
    </TouchableOpacity>
  ) : (
    <TouchableOpacity onPress={togglePasswordVisibility} style={styles.iconContainer}>
      <Eye size={normalize(20)} color={themeColors.subtext} />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, containerStyle]}>
      {label && <Text style={[styles.label, { color: themeColors.text }]}>{label}</Text>}
      <View
        style={[
          styles.inputContainer,
          {
            borderColor: error
              ? themeColors.error
              : isFocused
              ? themeColors.primary
              : themeColors.border,
            backgroundColor: themeColors.card,
          },
        ]}
      >
        {leftIcon && <View style={styles.iconContainer}>{leftIcon}</View>}
        <TextInput
          style={[
            styles.input,
            { color: themeColors.text },
            leftIcon && styles.inputWithLeftIcon,
            (rightIcon || isPassword || showClearButton) && styles.inputWithRightIcon,
          ]}
          placeholderTextColor={themeColors.subtext}
          onFocus={handleFocus}
          onBlur={handleBlur}
          secureTextEntry={!showPassword}
          {...rest}
        />
        {showClearButton && rest.value && rest.value.length > 0 && (
          <TouchableOpacity onPress={onClear} style={styles.iconContainer}>
            <Text style={{ fontSize: responsiveFontSize(18), color: themeColors.subtext }}>✕</Text>
          </TouchableOpacity>
        )}
        {isPassword && passwordIcon}
        {rightIcon && !isPassword && <View style={styles.iconContainer}>{rightIcon}</View>}
      </View>
      {error && <Text style={[styles.error, { color: themeColors.error }]}>{error}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: normalize(16),
  },
  label: {
    marginBottom: normalize(6),
    fontSize: responsiveFontSize(14),
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: layout.borderRadius.medium,
    overflow: 'hidden',
  },
  input: {
    flex: 1,
    paddingVertical: normalize(12),
    paddingHorizontal: normalize(12),
    fontSize: responsiveFontSize(16),
  },
  inputWithLeftIcon: {
    paddingLeft: normalize(8),
  },
  inputWithRightIcon: {
    paddingRight: normalize(8),
  },
  iconContainer: {
    paddingHorizontal: normalize(12),
    justifyContent: 'center',
    alignItems: 'center',
  },
  error: {
    marginTop: normalize(4),
    fontSize: responsiveFontSize(12),
  },
});