import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ingredient } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Check, Plus, ShoppingCart } from 'lucide-react-native';

interface IngredientItemProps {
  ingredient: Ingredient;
  servings?: number;
  originalServings?: number;
  isInShoppingList?: boolean;
  onAddToShoppingList?: () => void;
}

export const IngredientItem: React.FC<IngredientItemProps> = ({
  ingredient,
  servings,
  originalServings = 1,
  isInShoppingList = false,
  onAddToShoppingList,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  // Calculate adjusted amount based on servings
  const amount = servings && originalServings 
    ? (ingredient.amount * servings) / originalServings 
    : ingredient.amount;

  // Format the amount (round to 2 decimal places if needed)
  const formattedAmount = Number.isInteger(amount) 
    ? amount.toString() 
    : amount.toFixed(2).replace(/\.00$/, '').replace(/\.0$/, '');

  return (
    <View style={[
      styles.container, 
      { borderBottomColor: themeColors.border }
    ]}>
      <View style={styles.infoContainer}>
        <Text style={[styles.name, { color: themeColors.text }]}>
          {ingredient.name}
          {ingredient.optional && <Text style={styles.optional}> (optional)</Text>}
        </Text>
        <Text style={[styles.amount, { color: themeColors.subtext }]}>
          {formattedAmount} {ingredient.unit}
        </Text>
      </View>
      
      {onAddToShoppingList && (
        <TouchableOpacity 
          style={[
            styles.addButton,
            { 
              backgroundColor: isInShoppingList 
                ? themeColors.success 
                : themeColors.card,
              borderColor: isInShoppingList 
                ? themeColors.success 
                : themeColors.border,
            }
          ]} 
          onPress={onAddToShoppingList}
        >
          {isInShoppingList ? (
            <Check size={16} color="white" />
          ) : (
            <Plus size={16} color={themeColors.primary} />
          )}
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 2,
  },
  amount: {
    fontSize: 14,
  },
  optional: {
    fontStyle: 'italic',
    fontWeight: 'normal',
  },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
});