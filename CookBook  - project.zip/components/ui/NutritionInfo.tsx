import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NutritionInfo as NutritionInfoType } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Card } from './Card';

interface NutritionInfoProps {
  nutritionInfo: NutritionInfoType;
}

export const NutritionInfo: React.FC<NutritionInfoProps> = ({ nutritionInfo }) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  const nutritionItems = [
    { label: 'Calories', value: `${nutritionInfo.calories} kcal` },
    { label: 'Protein', value: `${nutritionInfo.protein}g` },
    { label: 'Carbs', value: `${nutritionInfo.carbs}g` },
    { label: 'Fat', value: `${nutritionInfo.fat}g` },
  ];

  if (nutritionInfo.fiber) {
    nutritionItems.push({ label: 'Fiber', value: `${nutritionInfo.fiber}g` });
  }

  if (nutritionInfo.sugar) {
    nutritionItems.push({ label: 'Sugar', value: `${nutritionInfo.sugar}g` });
  }

  if (nutritionInfo.sodium) {
    nutritionItems.push({ label: 'Sodium', value: `${nutritionInfo.sodium}mg` });
  }

  return (
    <Card style={styles.container}>
      <Text style={[styles.title, { color: themeColors.text }]}>Nutrition Information</Text>
      
      <View style={styles.grid}>
        {nutritionItems.map((item, index) => (
          <View key={index} style={styles.gridItem}>
            <Text style={[styles.value, { color: themeColors.text }]}>{item.value}</Text>
            <Text style={[styles.label, { color: themeColors.subtext }]}>{item.label}</Text>
          </View>
        ))}
      </View>
      
      <Text style={[styles.disclaimer, { color: themeColors.subtext }]}>
        * Values are per serving
      </Text>
    </Card>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -8,
  },
  gridItem: {
    width: '33.333%',
    paddingHorizontal: 8,
    marginBottom: 16,
    alignItems: 'center',
  },
  value: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  label: {
    fontSize: 12,
  },
  disclaimer: {
    fontSize: 12,
    fontStyle: 'italic',
    marginTop: 8,
  },
});