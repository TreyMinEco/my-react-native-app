import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useThemeStore } from '@/store/theme-store';
import { colors } from '@/constants/colors';
import { normalize } from '@/constants/layout';
import { Recipe } from '@/types/recipe';
import { RecipeCard } from './RecipeCard';
import { ChevronRight } from 'lucide-react-native';

interface RecipeListProps {
  recipes: Recipe[];
  title: string;
  onViewAll?: () => void;
  horizontal?: boolean;
  variant?: 'vertical' | 'horizontal';
  showViewAll?: boolean;
  showsHorizontalScrollIndicator?: boolean;
}

export const RecipeList: React.FC<RecipeListProps> = ({ 
  recipes = [],
  title, 
  onViewAll, 
  horizontal = true,
  variant = 'vertical',
  showViewAll = true,
  showsHorizontalScrollIndicator = false,
}) => {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const handleRecipePress = (recipeId: string) => {
    router.push({
      pathname: '/recipe',
      params: { id: recipeId }
    });
  };
  
  if (!recipes || recipes.length === 0) {
    return null;
  }
  
  return (
    <View style={styles.container}>
      {title && (
        <View style={styles.header}>
          <Text style={[styles.title, { color: themeColors.text }]}>{title}</Text>
          {showViewAll && (
            <TouchableOpacity onPress={onViewAll} style={styles.viewAllButton}>
              <Text style={[styles.viewAllText, { color: themeColors.primary }]}>View All</Text>
              <ChevronRight size={normalize(16)} color={themeColors.primary} />
            </TouchableOpacity>
          )}
        </View>
      )}
      
      {horizontal ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={showsHorizontalScrollIndicator}
          contentContainerStyle={styles.scrollContent}
        >
          {recipes.map((recipe) => (
            <View key={recipe.id} style={styles.cardContainer}>
              <RecipeCard
                recipe={recipe}
                variant={variant}
                onPress={() => handleRecipePress(recipe.id)}
                style={variant === 'vertical' ? styles.verticalCard : styles.horizontalCard}
              />
            </View>
          ))}
        </ScrollView>
      ) : (
        <FlatList
          data={recipes}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.listItem}>
              <RecipeCard
                recipe={item}
                variant={variant}
                onPress={() => handleRecipePress(item.id)}
              />
            </View>
          )}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: normalize(24),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalize(12),
    paddingHorizontal: normalize(16),
  },
  title: {
    fontSize: normalize(18),
    fontWeight: '600',
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewAllText: {
    fontSize: normalize(14),
    fontWeight: '500',
  },
  scrollContent: {
    paddingLeft: normalize(16),
    paddingRight: normalize(16),
    gap: normalize(12),
  },
  cardContainer: {
    marginRight: normalize(12),
  },
  verticalCard: {
    width: normalize(180),
  },
  horizontalCard: {
    width: normalize(300),
  },
  listItem: {
    marginBottom: normalize(16),
    paddingHorizontal: normalize(16),
  },
});