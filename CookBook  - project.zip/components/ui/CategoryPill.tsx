import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Platform } from 'react-native';
import { useThemeStore } from '@/store/theme-store';
import { colors } from '@/constants/colors';
import { normalize } from '@/constants/layout';

interface CategoryPillProps {
  label: string;
  isSelected?: boolean;
  onPress: () => void;
}

export const CategoryPill: React.FC<CategoryPillProps> = ({ 
  label, 
  isSelected = false, 
  onPress 
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  return (
    <TouchableOpacity
      style={[
        styles.pill,
        { 
          backgroundColor: isSelected ? themeColors.primary : themeColors.card,
          borderColor: isSelected ? themeColors.primary : themeColors.border,
        }
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text 
        style={[
          styles.label,
          { color: isSelected ? '#FFFFFF' : themeColors.text }
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  pill: {
    paddingHorizontal: normalize(16),
    paddingVertical: normalize(8),
    borderRadius: normalize(20),
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: normalize(14),
    fontWeight: '500',
  },
});