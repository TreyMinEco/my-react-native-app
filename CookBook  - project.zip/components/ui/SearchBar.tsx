import React from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Search, Mic, Camera } from 'lucide-react-native';
import layout, { normalize, responsiveFontSize } from '@/constants/layout';

interface SearchBarProps {
  placeholder: string;
  value: string;
  onChangeText: (text: string) => void;
  onVoiceSearch?: () => void;
  onCameraSearch?: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  placeholder,
  value,
  onChangeText,
  onVoiceSearch,
  onCameraSearch,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  return (
    <View style={styles.container}>
      <View
        style={[
          styles.searchBar,
          {
            backgroundColor: themeColors.card,
            borderColor: themeColors.border,
          },
        ]}
      >
        <Search size={normalize(20)} color={themeColors.subtext} style={styles.searchIcon} />
        <TextInput
          style={[styles.input, { color: themeColors.text }]}
          placeholder={placeholder}
          placeholderTextColor={themeColors.subtext}
          value={value}
          onChangeText={onChangeText}
        />
        {onVoiceSearch && (
          <TouchableOpacity onPress={onVoiceSearch} style={styles.actionButton}>
            <Mic size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
        )}
        {onCameraSearch && (
          <TouchableOpacity onPress={onCameraSearch} style={styles.actionButton}>
            <Camera size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: normalize(16),
    marginBottom: normalize(24),
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: layout.borderRadius.large,
    paddingHorizontal: normalize(12),
    height: normalize(48),
  },
  searchIcon: {
    marginRight: normalize(8),
  },
  input: {
    flex: 1,
    fontSize: responsiveFontSize(16),
    height: '100%',
  },
  actionButton: {
    padding: normalize(8),
    marginLeft: normalize(4),
  },
});