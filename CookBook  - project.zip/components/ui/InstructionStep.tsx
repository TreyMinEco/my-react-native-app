import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Instruction } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Clock, Play } from 'lucide-react-native';
import { Button } from './Button';

interface InstructionStepProps {
  instruction: Instruction;
  isActive?: boolean;
  onTimerStart?: (seconds: number) => void;
}

export const InstructionStep: React.FC<InstructionStepProps> = ({
  instruction,
  isActive = false,
  onTimerStart,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const [imageExpanded, setImageExpanded] = useState(false);

  const hasTimer = instruction.timers && instruction.timers.length > 0;
  const hasImage = !!instruction.imageUrl;

  return (
    <View style={[
      styles.container, 
      isActive && styles.activeContainer,
      { 
        backgroundColor: isActive ? themeColors.highlight : 'transparent',
        borderColor: isActive ? themeColors.primary : themeColors.border,
      }
    ]}>
      <View style={styles.header}>
        <View style={[
          styles.stepNumber, 
          { 
            backgroundColor: isActive ? themeColors.primary : themeColors.card,
            borderColor: isActive ? themeColors.primary : themeColors.border,
          }
        ]}>
          <Text style={[
            styles.stepNumberText, 
            { color: isActive ? 'white' : themeColors.text }
          ]}>
            {instruction.step}
          </Text>
        </View>
        <Text style={[
          styles.description, 
          { color: themeColors.text }
        ]}>
          {instruction.description}
        </Text>
      </View>
      
      {hasImage && (
        <TouchableOpacity 
          onPress={() => setImageExpanded(!imageExpanded)}
          activeOpacity={0.9}
        >
          <Image 
            source={{ uri: instruction.imageUrl }} 
            style={[
              styles.image,
              imageExpanded && styles.expandedImage
            ]}
          />
        </TouchableOpacity>
      )}
      
      {hasTimer && (
        <View style={styles.timersContainer}>
          {instruction.timers?.map((seconds, index) => (
            <Button
              key={index}
              title={`${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, '0')}`}
              onPress={() => onTimerStart && onTimerStart(seconds)}
              variant="outline"
              size="small"
              icon={<Clock size={14} color={themeColors.primary} />}
              style={styles.timerButton}
            />
          ))}
        </View>
      )}
      
      {instruction.videoUrl && (
        <TouchableOpacity 
          style={[
            styles.videoButton,
            { backgroundColor: themeColors.card }
          ]}
        >
          <Play size={16} color={themeColors.primary} />
          <Text style={[styles.videoButtonText, { color: themeColors.text }]}>
            Watch Video
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
  },
  activeContainer: {
    borderWidth: 1,
  },
  header: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
  },
  stepNumberText: {
    fontWeight: '600',
    fontSize: 14,
  },
  description: {
    flex: 1,
    fontSize: 16,
    lineHeight: 24,
  },
  image: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    marginBottom: 12,
  },
  expandedImage: {
    height: 240,
  },
  timersContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  timerButton: {
    minWidth: 80,
  },
  videoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
    gap: 6,
  },
  videoButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
});