import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { RecipeReview } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Star } from 'lucide-react-native';

interface ReviewItemProps {
  review: RecipeReview;
  onPress?: () => void;
}

export const ReviewItem: React.FC<ReviewItemProps> = ({ review, onPress }) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <TouchableOpacity 
      style={[
        styles.container, 
        { borderBottomColor: themeColors.border }
      ]}
      onPress={onPress}
      activeOpacity={onPress ? 0.7 : 1}
    >
      <View style={styles.header}>
        <View style={styles.userInfo}>
          {review.userAvatar ? (
            <Image source={{ uri: review.userAvatar }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: themeColors.primary }]}>
              <Text style={styles.avatarText}>
                {review.userName.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
          <View>
            <Text style={[styles.userName, { color: themeColors.text }]}>
              {review.userName}
            </Text>
            <Text style={[styles.date, { color: themeColors.subtext }]}>
              {formatDate(review.date)}
            </Text>
          </View>
        </View>
        <View style={styles.rating}>
          {[1, 2, 3, 4, 5].map((star) => (
            <Star 
              key={star}
              size={16} 
              color="#FFD700" 
              fill={star <= review.rating ? "#FFD700" : "transparent"} 
            />
          ))}
        </View>
      </View>
      
      <Text style={[styles.comment, { color: themeColors.text }]}>
        {review.comment}
      </Text>
      
      {review.images && review.images.length > 0 && (
        <View style={styles.imagesContainer}>
          {review.images.map((image, index) => (
            <Image key={index} source={{ uri: image }} style={styles.reviewImage} />
          ))}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  avatarPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
  },
  date: {
    fontSize: 12,
  },
  rating: {
    flexDirection: 'row',
    gap: 2,
  },
  comment: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 12,
  },
  imagesContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  reviewImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
});