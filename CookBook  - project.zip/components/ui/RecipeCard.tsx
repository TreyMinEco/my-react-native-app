import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  Platform,
  ViewStyle,
} from 'react-native';
import { useThemeStore } from '@/store/theme-store';
import { useUserStore } from '@/store/user-store';
import { colors } from '@/constants/colors';
import { normalize } from '@/constants/layout';
import { Recipe } from '@/types/recipe';
import { Heart, Clock, ChefHat } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

interface RecipeCardProps {
  recipe: Recipe;
  variant?: 'vertical' | 'horizontal';
  onPress?: () => void;
  style?: ViewStyle;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ 
  recipe, 
  variant = 'vertical',
  onPress,
  style,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { addToFavorites, removeFromFavorites, isFavorite } = useUserStore();
  
  const isVertical = variant === 'vertical';
  
  const handleFavoriteToggle = (e: any) => {
    if (e) {
      e.stopPropagation();
    }
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (isFavorite(recipe.id)) {
      removeFromFavorites(recipe.id);
    } else {
      addToFavorites(recipe.id);
    }
  };
  
  if (!recipe) {
    return null;
  }
  
  return (
    <TouchableOpacity 
      style={[
        styles.container,
        isVertical ? styles.verticalContainer : styles.horizontalContainer,
        { backgroundColor: themeColors.card },
        style,
      ]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={isVertical ? styles.verticalImageContainer : styles.horizontalImageContainer}>
        <Image 
          source={{ uri: recipe.imageUrl }} 
          style={styles.image} 
          resizeMode="cover"
        />
        <TouchableOpacity 
          style={styles.favoriteButton}
          onPress={handleFavoriteToggle}
        >
          <Heart 
            size={normalize(18)} 
            color="#FFFFFF" 
            fill={isFavorite(recipe.id) ? "#FF4081" : "transparent"} 
            stroke={isFavorite(recipe.id) ? "#FF4081" : "#FFFFFF"}
          />
        </TouchableOpacity>
      </View>
      
      <View style={isVertical ? styles.verticalContent : styles.horizontalContent}>
        <Text 
          style={[styles.title, { color: themeColors.text }]}
          numberOfLines={2}
        >
          {recipe.title}
        </Text>
        
        <View style={styles.metaContainer}>
          <View style={styles.metaItem}>
            <Clock size={normalize(12)} color={themeColors.subtext} />
            <Text style={[styles.metaText, { color: themeColors.subtext }]}>
              {recipe.totalTime} min
            </Text>
          </View>
          
          <View style={styles.metaItem}>
            <ChefHat size={normalize(12)} color={themeColors.subtext} />
            <Text style={[styles.metaText, { color: themeColors.subtext }]}>
              {recipe.difficulty}
            </Text>
          </View>
        </View>
        
        {!isVertical && (
          <Text 
            style={[styles.description, { color: themeColors.subtext }]}
            numberOfLines={2}
          >
            {recipe.description}
          </Text>
        )}
        
        {recipe.dietaryTags && recipe.dietaryTags.length > 0 && (
          <View style={styles.tagsContainer}>
            {recipe.dietaryTags.slice(0, isVertical ? 1 : 2).map((tag, index) => (
              <View 
                key={index} 
                style={[
                  styles.tag, 
                  { 
                    backgroundColor: themeColors.background,
                  }
                ]}
              >
                <Text style={[styles.tagText, { color: themeColors.text }]}>
                  {tag}
                </Text>
              </View>
            ))}
            {recipe.dietaryTags.length > (isVertical ? 1 : 2) && (
              <View 
                style={[
                  styles.tag, 
                  { 
                    backgroundColor: themeColors.background,
                  }
                ]}
              >
                <Text style={[styles.tagText, { color: themeColors.text }]}>
                  +{recipe.dietaryTags.length - (isVertical ? 1 : 2)}
                </Text>
              </View>
            )}
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: normalize(12),
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  verticalContainer: {
    width: '100%',
  },
  horizontalContainer: {
    flexDirection: 'row',
    height: normalize(120),
  },
  verticalImageContainer: {
    height: normalize(150),
    width: '100%',
  },
  horizontalImageContainer: {
    width: normalize(120),
    height: '100%',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  favoriteButton: {
    position: 'absolute',
    top: normalize(8),
    right: normalize(8),
    width: normalize(32),
    height: normalize(32),
    borderRadius: normalize(16),
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verticalContent: {
    padding: normalize(12),
  },
  horizontalContent: {
    flex: 1,
    padding: normalize(12),
    justifyContent: 'space-between',
  },
  title: {
    fontSize: normalize(16),
    fontWeight: '600',
    marginBottom: normalize(8),
  },
  metaContainer: {
    flexDirection: 'row',
    marginBottom: normalize(8),
    gap: normalize(12),
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: normalize(4),
  },
  metaText: {
    fontSize: normalize(12),
  },
  description: {
    fontSize: normalize(12),
    marginBottom: normalize(8),
    lineHeight: normalize(16),
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: normalize(4),
  },
  tag: {
    paddingHorizontal: normalize(6),
    paddingVertical: normalize(2),
    borderRadius: normalize(4),
  },
  tagText: {
    fontSize: normalize(10),
    fontWeight: '500',
  },
});