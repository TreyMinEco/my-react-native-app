import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ShoppingListItem as ShoppingListItemType } from '@/types/recipe';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Check, Trash2 } from 'lucide-react-native';

interface ShoppingListItemProps {
  item: ShoppingListItemType;
  onToggle: () => void;
  onDelete: () => void;
}

export const ShoppingListItem: React.FC<ShoppingListItemProps> = ({
  item,
  onToggle,
  onDelete,
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  return (
    <View style={[
      styles.container, 
      { borderBottomColor: themeColors.border }
    ]}>
      <TouchableOpacity 
        style={styles.checkContainer} 
        onPress={onToggle}
        activeOpacity={0.7}
      >
        <View style={[
          styles.checkbox,
          {
            backgroundColor: item.checked ? themeColors.primary : 'transparent',
            borderColor: item.checked ? themeColors.primary : themeColors.border,
          }
        ]}>
          {item.checked && <Check size={14} color="white" />}
        </View>
        <View style={styles.textContainer}>
          <Text 
            style={[
              styles.name, 
              { 
                color: themeColors.text,
                textDecorationLine: item.checked ? 'line-through' : 'none',
                opacity: item.checked ? 0.6 : 1,
              }
            ]}
          >
            {item.name}
          </Text>
          <Text style={[styles.amount, { color: themeColors.subtext }]}>
            {item.amount} {item.unit} • {item.recipeName}
          </Text>
        </View>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={styles.deleteButton} 
        onPress={onDelete}
        hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
      >
        <Trash2 size={18} color={themeColors.error} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  checkContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 4,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 2,
  },
  amount: {
    fontSize: 14,
  },
  deleteButton: {
    padding: 4,
  },
});