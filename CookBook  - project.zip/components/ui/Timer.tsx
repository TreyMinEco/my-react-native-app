import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Easing } from 'react-native';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { Play, Pause, X, Volume2, VolumeX } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

interface TimerProps {
  seconds: number;
  onComplete?: () => void;
  onClose?: () => void;
}

export const Timer: React.FC<TimerProps> = ({
  seconds: initialSeconds,
  onComplete,
  onClose,
}) => {
  const [seconds, setSeconds] = useState(initialSeconds);
  const [isRunning, setIsRunning] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const progressAnim = useRef(new Animated.Value(0)).current;
  const animation = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    if (isRunning) {
      const timer = setInterval(() => {
        setSeconds(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            if (onComplete) onComplete();
            if (Platform.OS !== 'web') {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      // Start progress animation
      animation.current = Animated.timing(progressAnim, {
        toValue: 1,
        duration: seconds * 1000,
        easing: Easing.linear,
        useNativeDriver: false,
      });
      animation.current.start();
      
      return () => {
        clearInterval(timer);
        if (animation.current) {
          animation.current.stop();
        }
      };
    }
  }, [isRunning, seconds, onComplete]);

  const toggleTimer = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setIsRunning(!isRunning);
    
    if (isRunning && animation.current) {
      animation.current.stop();
    } else {
      // Recalculate animation duration based on remaining time
      animation.current = Animated.timing(progressAnim, {
        toValue: 1,
        duration: seconds * 1000,
        easing: Easing.linear,
        useNativeDriver: false,
      });
      animation.current.start();
    }
  };

  const toggleMute = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setIsMuted(!isMuted);
  };

  const handleClose = () => {
    if (onClose) onClose();
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressInterpolate = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={[styles.container, { backgroundColor: themeColors.card }]}>
      <View style={styles.progressContainer}>
        <Animated.View 
          style={[
            styles.progressBar, 
            { 
              backgroundColor: themeColors.primary,
              width: progressInterpolate 
            }
          ]} 
        />
      </View>
      
      <View style={styles.content}>
        <Text style={[styles.time, { color: themeColors.text}]}>
          {formatTime(seconds)}
        </Text>
        
        <View style={styles.controls}>
          <TouchableOpacity 
            style={[styles.controlButton, {backgroundColor: themeColors.background}]} 
            onPress={toggleTimer}
          >
            {isRunning ? (
              <Pause size={20} color={themeColors.text} />
            ) : (
              <Play size={20} color={themeColors.text} />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.controlButton, {backgroundColor: themeColors.background}]} 
            onPress={toggleMute}
          >
            {isMuted ? (
              <VolumeX size={20} color={themeColors.text} />
            ) : (
              <Volume2 size={20} color={themeColors.text} />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.controlButton, {backgroundColor: themeColors.background}]} 
            onPress={handleClose}
          >
            <X size={20} color={themeColors.text} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    overflow: 'hidden',
    marginVertical: 16,
  },
  progressContainer: {
    height: 4,
    width: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
  progressBar: {
    height: '100%',
  },
  content: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  time: {
    fontSize: 24,
    fontWeight: '700',
  },
  controls: {
    flexDirection: 'row',
    gap: 8,
  },
  controlButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});