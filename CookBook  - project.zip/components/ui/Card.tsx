import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import layout, { normalize } from '@/constants/layout';

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  variant?: 'elevated' | 'outlined' | 'filled';
  padding?: 'none' | 'small' | 'medium' | 'large';
}

export const Card: React.FC<CardProps> = ({
  children,
  style,
  variant = 'elevated',
  padding = 'medium',
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];

  const cardStyles = [
    styles.card,
    styles[`${padding}Padding`],
    variant === 'elevated' && [
      styles.elevatedCard,
      { backgroundColor: themeColors.card }
    ],
    variant === 'outlined' && [
      styles.outlinedCard,
      { 
        borderColor: themeColors.border,
        backgroundColor: themeColors.background
      }
    ],
    variant === 'filled' && [
      styles.filledCard,
      { backgroundColor: themeColors.card }
    ],
    style,
  ];

  return <View style={cardStyles}>{children}</View>;
};

const styles = StyleSheet.create({
  card: {
    borderRadius: layout.borderRadius.large,
    overflow: 'hidden',
  },
  elevatedCard: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  outlinedCard: {
    borderWidth: 1,
  },
  filledCard: {
    // No additional styles needed
  },
  nonePadding: {
    padding: 0,
  },
  smallPadding: {
    padding: normalize(8),
  },
  mediumPadding: {
    padding: normalize(16),
  },
  largePadding: {
    padding: normalize(24),
  },
});