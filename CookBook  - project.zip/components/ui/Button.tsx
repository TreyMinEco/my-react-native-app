import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator,
  TouchableOpacityProps,
  ViewStyle,
  TextStyle,
  Platform,
} from 'react-native';
import { colors } from '@/constants/colors';
import { LinearGradient } from 'expo-linear-gradient';
import layout, { normalize, responsiveFontSize } from '@/constants/layout';
import { useThemeStore } from '@/store/theme-store';

interface ButtonProps extends TouchableOpacityProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'small' | 'medium' | 'large';
  isLoading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  gradientColors?: [string, string];
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  isLoading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  style,
  textStyle,
  gradientColors,
  disabled,
  ...rest
}) => {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const buttonStyles = [
    styles.button,
    styles[`${variant}Button`],
    styles[`${size}Button`],
    fullWidth && styles.fullWidth,
    disabled && styles.disabledButton,
    style,
  ];

  const textStyles = [
    styles.text,
    styles[`${variant}Text`],
    styles[`${size}Text`],
    disabled && styles.disabledText,
    textStyle,
  ];

  const content = (
    <>
      {isLoading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'primary' ? 'white' : themeColors.primary} 
        />
      ) : (
        <>
          {icon && iconPosition === 'left' && icon}
          <Text style={textStyles}>{title}</Text>
          {icon && iconPosition === 'right' && icon}
        </>
      )}
    </>
  );

  // Use LinearGradient for primary buttons on native platforms
  if (variant === 'primary' && Platform.OS !== 'web' && gradientColors) {
    // Use provided colors or defaults
    const safeColors: [string, string] = gradientColors || [themeColors.primary, themeColors.accent];
    
    return (
      <TouchableOpacity
        onPress={onPress}
        disabled={isLoading || disabled}
        style={[styles.buttonContainer, fullWidth && styles.fullWidth, style]}
        activeOpacity={0.8}
        {...rest}
      >
        <LinearGradient
          colors={safeColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[
            styles.button,
            styles.primaryButton,
            styles[`${size}Button`],
            disabled && styles.disabledButton,
          ]}
        >
          {content}
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  // Default button without gradient
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isLoading || disabled}
      style={buttonStyles}
      activeOpacity={0.8}
      {...rest}
    >
      {content}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    borderRadius: layout.borderRadius.large,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: layout.borderRadius.large,
    gap: normalize(8),
  },
  primaryButton: {
    backgroundColor: colors.light.primary,
  },
  secondaryButton: {
    backgroundColor: colors.light.secondary,
  },
  outlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.light.primary,
  },
  ghostButton: {
    backgroundColor: 'transparent',
  },
  smallButton: {
    paddingVertical: normalize(8),
    paddingHorizontal: normalize(12),
  },
  mediumButton: {
    paddingVertical: normalize(12),
    paddingHorizontal: normalize(16),
  },
  largeButton: {
    paddingVertical: normalize(16),
    paddingHorizontal: normalize(20),
  },
  fullWidth: {
    width: '100%',
  },
  disabledButton: {
    backgroundColor: colors.light.inactive,
    borderColor: colors.light.inactive,
    opacity: 0.7,
  },
  text: {
    fontWeight: '600',
    textAlign: 'center',
  },
  primaryText: {
    color: 'white',
  },
  secondaryText: {
    color: 'white',
  },
  outlineText: {
    color: colors.light.primary,
  },
  ghostText: {
    color: colors.light.primary,
  },
  smallText: {
    fontSize: responsiveFontSize(14),
  },
  mediumText: {
    fontSize: responsiveFontSize(16),
  },
  largeText: {
    fontSize: responsiveFontSize(18),
  },
  disabledText: {
    color: colors.light.subtext,
  },
});