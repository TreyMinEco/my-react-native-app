import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ShoppingListItem, MealPlan, MealPlanDay } from '@/types/recipe';

type UserState = {
  preferences: {
    theme: 'light' | 'dark' | 'system';
    measurementSystem: 'metric' | 'imperial';
    notificationsEnabled: boolean;
    pushNotifications: {
      newRecipes: boolean;
      mealReminders: boolean;
      tips: boolean;
    };
  };
  favorites: string[];
  history: Array<{ recipeId: string; viewedAt: string }>;
  shoppingList: ShoppingListItem[];
  mealPlans: MealPlan[];
  createdRecipes: string[];
  
  // Favorites actions
  addToFavorites: (recipeId: string) => void;
  removeFromFavorites: (recipeId: string) => void;
  isFavorite: (recipeId: string) => boolean;
  
  // History actions
  addToHistory: (recipeId: string) => void;
  clearHistory: () => void;
  
  // Shopping list actions
  addToShoppingList: (item: Omit<ShoppingListItem, 'id'>) => void;
  removeFromShoppingList: (itemId: string) => void;
  updateShoppingListItem: (itemId: string, updates: Partial<ShoppingListItem>) => void;
  clearShoppingList: () => void;
  
  // Meal plan actions
  addMealPlan: (mealPlan: Omit<MealPlan, 'id'>) => void;
  updateMealPlan: (mealPlanId: string, updates: Partial<MealPlan>) => void;
  removeMealPlan: (mealPlanId: string) => void;
  addRecipeToMealPlan: (mealPlanId: string, date: string, mealType: string, recipeId: string) => void;
  removeRecipeFromMealPlan: (mealPlanId: string, date: string, mealType: string, recipeId: string) => void;
  
  // Preferences actions
  updatePreferences: (preferences: Partial<UserState['preferences']>) => void;
};

// Default preferences
const defaultPreferences = {
  theme: 'system' as const,
  measurementSystem: 'metric' as const,
  notificationsEnabled: true,
  pushNotifications: {
    newRecipes: true,
    mealReminders: true,
    tips: true,
  },
};

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      preferences: defaultPreferences,
      favorites: [],
      history: [],
      shoppingList: [],
      mealPlans: [],
      createdRecipes: [],
      
      addToFavorites: (recipeId) => {
        const { favorites } = get();
        
        if (!favorites.includes(recipeId)) {
          set({ 
            favorites: [...favorites, recipeId] 
          });
        }
      },
      
      removeFromFavorites: (recipeId) => {
        const { favorites } = get();
        
        set({ 
          favorites: favorites.filter(id => id !== recipeId) 
        });
      },
      
      isFavorite: (recipeId) => {
        const { favorites } = get();
        return favorites.includes(recipeId);
      },
      
      addToHistory: (recipeId) => {
        const { history } = get();
        
        const newHistoryItem = { 
          recipeId, 
          viewedAt: new Date().toISOString() 
        };
        
        // Remove if already exists to avoid duplicates
        const filteredHistory = history.filter(
          item => item.recipeId !== recipeId
        );
        
        // Limit history to 50 items
        const limitedHistory = [newHistoryItem, ...filteredHistory].slice(0, 50);
        
        set({ 
          history: limitedHistory
        });
      },
      
      clearHistory: () => {
        set({ history: [] });
      },
      
      addToShoppingList: (item) => {
        const { shoppingList } = get();
        
        // Check if item already exists with same name and recipe
        const existingItem = shoppingList.find(
          i => i.name.toLowerCase() === item.name.toLowerCase() && 
               i.recipeId === item.recipeId
        );
        
        if (existingItem) {
          // Update existing item quantity
          set({
            shoppingList: shoppingList.map(i => 
              i.id === existingItem.id 
                ? { ...i, amount: i.amount + item.amount } 
                : i
            )
          });
        } else {
          // Add new item
          const newItem: ShoppingListItem = {
            ...item,
            id: Math.random().toString(36).substring(2, 9),
          };
          
          set({ 
            shoppingList: [...shoppingList, newItem] 
          });
        }
      },
      
      removeFromShoppingList: (itemId) => {
        const { shoppingList } = get();
        
        set({ 
          shoppingList: shoppingList.filter(item => item.id !== itemId) 
        });
      },
      
      updateShoppingListItem: (itemId, updates) => {
        const { shoppingList } = get();
        
        set({ 
          shoppingList: shoppingList.map(item => 
            item.id === itemId ? { ...item, ...updates } : item
          ) 
        });
      },
      
      clearShoppingList: () => {
        set({ shoppingList: [] });
      },
      
      addMealPlan: (mealPlan) => {
        const { mealPlans } = get();
        
        const newMealPlan: MealPlan = {
          ...mealPlan,
          id: Math.random().toString(36).substring(2, 9),
        };
        
        set({ 
          mealPlans: [...mealPlans, newMealPlan] 
        });
      },
      
      updateMealPlan: (mealPlanId, updates) => {
        const { mealPlans } = get();
        
        set({ 
          mealPlans: mealPlans.map(plan => 
            plan.id === mealPlanId ? { ...plan, ...updates } : plan
          ) 
        });
      },
      
      removeMealPlan: (mealPlanId) => {
        const { mealPlans } = get();
        
        set({ 
          mealPlans: mealPlans.filter(plan => plan.id !== mealPlanId) 
        });
      },
      
      addRecipeToMealPlan: (mealPlanId, date, mealType, recipeId) => {
        const { mealPlans } = get();
        
        set({ 
          mealPlans: mealPlans.map(plan => {
            if (plan.id !== mealPlanId) return plan;
            
            const dayIndex = plan.days.findIndex(day => day.date === date);
            
            if (dayIndex === -1) {
              // Day doesn't exist, create it
              const newDay: MealPlanDay = { date };
              (newDay as any)[mealType] = [recipeId];
              return {
                ...plan,
                days: [...plan.days, newDay],
              };
            } else {
              // Day exists, update it
              const updatedDays = [...plan.days];
              const day = updatedDays[dayIndex];
              
              if (!day[mealType as keyof typeof day]) {
                (day as any)[mealType] = [recipeId];
              } else {
                const recipes = (day as any)[mealType] as string[];
                if (!recipes.includes(recipeId)) {
                  (day as any)[mealType] = [...recipes, recipeId];
                }
              }
              
              return {
                ...plan,
                days: updatedDays,
              };
            }
          }) 
        });
      },
      
      removeRecipeFromMealPlan: (mealPlanId, date, mealType, recipeId) => {
        const { mealPlans } = get();
        
        set({ 
          mealPlans: mealPlans.map(plan => {
            if (plan.id !== mealPlanId) return plan;
            
            const dayIndex = plan.days.findIndex(day => day.date === date);
            if (dayIndex === -1) return plan;
            
            const updatedDays = [...plan.days];
            const day = updatedDays[dayIndex];
            
            if (day[mealType as keyof typeof day]) {
              const recipes = (day as any)[mealType] as string[];
              (day as any)[mealType] = recipes.filter(id => id !== recipeId);
            }
            
            return {
              ...plan,
              days: updatedDays,
            };
          }) 
        });
      },
      
      updatePreferences: (preferencesUpdates) => {
        const { preferences } = get();
        
        set({ 
          preferences: { 
            ...preferences, 
            ...preferencesUpdates 
          } 
        });
      },
    }),
    {
      name: 'user-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        preferences: state.preferences,
        favorites: state.favorites,
        history: state.history,
        shoppingList: state.shoppingList,
        mealPlans: state.mealPlans,
        createdRecipes: state.createdRecipes,
      }),
    }
  )
);

// Helper function to access user profile data
export const useUserProfile = () => {
  const userStore = useUserStore();
  return {
    profile: {
      preferences: userStore.preferences,
      favorites: userStore.favorites,
      history: userStore.history,
      shoppingList: userStore.shoppingList,
      mealPlans: userStore.mealPlans,
      createdRecipes: userStore.createdRecipes,
    }
  };
};