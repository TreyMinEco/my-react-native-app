import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Recipe, RecipeFilters } from '@/types/recipe';
import { mockRecipes } from '@/mocks/recipes';

type RecipeState = {
  recipes: Recipe[];
  featuredRecipes: Recipe[];
  popularRecipes: Recipe[];
  recentRecipes: Recipe[];
  filters: RecipeFilters;
  searchQuery: string;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setRecipes: (recipes: Recipe[]) => void;
  setFeaturedRecipes: (recipes: Recipe[]) => void;
  setPopularRecipes: (recipes: Recipe[]) => void;
  setRecentRecipes: (recipes: Recipe[]) => void;
  setFilters: (filters: RecipeFilters) => void;
  setSearchQuery: (query: string) => void;
  setIsLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  
  // Computed
  getFilteredRecipes: () => Recipe[];
  getRecipeById: (id: string) => Recipe | undefined;
  getRecipesByIngredients: (ingredients: string[]) => Recipe[];
  getRecipesByCuisine: (cuisine: string) => Recipe[];
  getRecipesByMealType: (mealType: string) => Recipe[];
  getRecipesByDietaryTags: (tags: string[]) => Recipe[];
};

export const useRecipeStore = create<RecipeState>()(
  persist(
    (set, get) => ({
      recipes: mockRecipes,
      featuredRecipes: mockRecipes.filter(r => r.isFeatured),
      popularRecipes: [...mockRecipes].sort((a, b) => b.rating - a.rating).slice(0, 10),
      recentRecipes: [...mockRecipes].sort((a, b) => 
        new Date(b.datePublished).getTime() - new Date(a.datePublished).getTime()
      ).slice(0, 10),
      filters: {},
      searchQuery: '',
      isLoading: false,
      error: null,
      
      setRecipes: (recipes) => set({ recipes }),
      setFeaturedRecipes: (recipes) => set({ featuredRecipes: recipes }),
      setPopularRecipes: (recipes) => set({ popularRecipes: recipes }),
      setRecentRecipes: (recipes) => set({ recentRecipes: recipes }),
      setFilters: (filters) => set({ filters }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      setIsLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error }),
      
      getFilteredRecipes: () => {
        const { recipes, filters, searchQuery } = get();
        let filtered = [...recipes];
        
        // Apply search query
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          filtered = filtered.filter(recipe => 
            recipe.title.toLowerCase().includes(query) || 
            recipe.description.toLowerCase().includes(query) ||
            recipe.ingredients.some(ing => ing.name.toLowerCase().includes(query))
          );
        }
        
        // Apply filters
        if (filters.ingredients && filters.ingredients.length > 0) {
          filtered = filtered.filter(recipe => 
            filters.ingredients!.every(ingredient => 
              recipe.ingredients.some(ing => 
                ing.name.toLowerCase().includes(ingredient.toLowerCase())
              )
            )
          );
        }
        
        if (filters.cuisine && filters.cuisine.length > 0) {
          filtered = filtered.filter(recipe => 
            filters.cuisine!.includes(recipe.cuisine)
          );
        }
        
        if (filters.mealType && filters.mealType.length > 0) {
          filtered = filtered.filter(recipe => 
            recipe.mealType.some(type => filters.mealType!.includes(type))
          );
        }
        
        if (filters.dietaryTags && filters.dietaryTags.length > 0) {
          filtered = filtered.filter(recipe => 
            filters.dietaryTags!.every(tag => 
              recipe.dietaryTags.includes(tag)
            )
          );
        }
        
        if (filters.maxPrepTime) {
          filtered = filtered.filter(recipe => recipe.prepTime <= filters.maxPrepTime!);
        }
        
        if (filters.maxCookTime) {
          filtered = filtered.filter(recipe => recipe.cookTime <= filters.maxCookTime!);
        }
        
        if (filters.maxCalories) {
          filtered = filtered.filter(recipe => recipe.nutritionInfo.calories <= filters.maxCalories!);
        }
        
        if (filters.difficulty && filters.difficulty.length > 0) {
          filtered = filtered.filter(recipe => filters.difficulty!.includes(recipe.difficulty));
        }
        
        return filtered;
      },
      
      getRecipeById: (id) => {
        return get().recipes.find(recipe => recipe.id === id);
      },
      
      getRecipesByIngredients: (ingredients) => {
        const { recipes } = get();
        
        if (ingredients.length === 0) return [];
        
        // First, find recipes that contain ALL the specified ingredients
        const exactMatches = recipes.filter(recipe => 
          ingredients.every(ingredient => 
            recipe.ingredients.some(ing => 
              ing.name.toLowerCase().includes(ingredient.toLowerCase())
            )
          )
        );
        
        // If we have exact matches, return them
        if (exactMatches.length > 0) {
          return exactMatches;
        }
        
        // Otherwise, find recipes that contain MOST of the specified ingredients
        // Calculate a match score for each recipe
        const recipeScores = recipes.map(recipe => {
          let matchCount = 0;
          ingredients.forEach(ingredient => {
            if (recipe.ingredients.some(ing => 
              ing.name.toLowerCase().includes(ingredient.toLowerCase())
            )) {
              matchCount++;
            }
          });
          
          // Calculate match percentage
          const matchPercentage = (matchCount / ingredients.length) * 100;
          
          return {
            recipe,
            matchPercentage,
            matchCount
          };
        });
        
        // Filter recipes that match at least 50% of ingredients
        const partialMatches = recipeScores
          .filter(item => item.matchPercentage >= 50)
          .sort((a, b) => b.matchPercentage - a.matchPercentage)
          .map(item => item.recipe);
        
        return partialMatches;
      },
      
      getRecipesByCuisine: (cuisine) => {
        const { recipes } = get();
        return recipes.filter(recipe => recipe.cuisine.toLowerCase() === cuisine.toLowerCase());
      },
      
      getRecipesByMealType: (mealType) => {
        const { recipes } = get();
        return recipes.filter(recipe => 
          recipe.mealType.some(type => type.toLowerCase() === mealType.toLowerCase())
        );
      },
      
      getRecipesByDietaryTags: (tags) => {
        const { recipes } = get();
        return recipes.filter(recipe => 
          tags.every(tag => 
            recipe.dietaryTags.some(t => t.toLowerCase() === tag.toLowerCase())
          )
        );
      },
    }),
    {
      name: 'recipe-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        // Only persist these fields
        recipes: state.recipes,
      }),
    }
  )
);