import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Recipe } from '@/types/recipe';
import { useLanguageStore } from './language-store';

type GeneratedRecipe = {
  title: string;
  description?: string;
  cookingTimeMinutes: number;
  servings: number;
  ingredients: {
    name: string;
    amount: number;
    unit: string;
  }[];
  instructions: string[];
  createdAt: string;
};

type AIState = {
  generatedRecipe: GeneratedRecipe | null;
  savedRecipes: GeneratedRecipe[];
  isLoading: boolean;
  error: string | null;
  recipeLanguage: string;
  generateRecipe: (dishName: string, language: string) => Promise<void>;
  saveRecipe: (recipe: GeneratedRecipe) => void;
  clearError: () => void;
  setRecipeLanguage: (language: string) => void;
};

export const useAIStore = create<AIState>()(
  persist(
    (set, get) => ({
      generatedRecipe: null,
      savedRecipes: [],
      isLoading: false,
      error: null,
      recipeLanguage: 'en', // Default language
      
      generateRecipe: async (dishName: string, language: string) => {
        set({ isLoading: true, error: null });
        
        try {
          const prompt = `Create a detailed recipe for ${dishName}. 
          Include a title, brief description, cooking time in minutes, number of servings, 
          ingredients with amounts and units, and step-by-step instructions. 
          Format your response in JSON with the following structure:
          {
            "title": "Recipe Title",
            "description": "Brief description of the dish",
            "cookingTimeMinutes": 30,
            "servings": 4,
            "ingredients": [
              {"name": "ingredient name", "amount": 1, "unit": "cup"}
            ],
            "instructions": [
              "Step 1 instruction",
              "Step 2 instruction"
            ]
          }
          
          Please respond in ${language} language.
          Make sure all text fields (title, description, ingredient names, instructions) are in ${language}.
          Keep the JSON structure in valid format.`;
          
          const response = await fetch('https://toolkit.rork.com/text/llm/', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              messages: [
                { role: 'system', content: 'You are a professional chef who creates detailed recipes.' },
                { role: 'user', content: prompt }
              ]
            }),
          });
          
          if (!response.ok) {
            throw new Error('Failed to generate recipe. Please try again.');
          }
          
          const data = await response.json();
          const completion = data.completion;
          
          // Extract JSON from the response
          const jsonMatch = completion.match(/```json\n([\s\S]*?)\n```/) || 
                           completion.match(/```\n([\s\S]*?)\n```/) ||
                           completion.match(/{[\s\S]*?}/);
          
          let recipeData;
          
          if (jsonMatch) {
            // If JSON is in a code block, extract it
            const jsonString = jsonMatch[1] || jsonMatch[0];
            recipeData = JSON.parse(jsonString);
          } else {
            // Try to parse the whole response as JSON
            try {
              recipeData = JSON.parse(completion);
            } catch (e) {
              throw new Error('Could not parse recipe data. Please try again.');
            }
          }
          
          // Validate the recipe data
          if (!recipeData.title || !recipeData.ingredients || !recipeData.instructions) {
            throw new Error('Generated recipe is incomplete. Please try again.');
          }
          
          const generatedRecipe: GeneratedRecipe = {
            ...recipeData,
            createdAt: new Date().toISOString(),
          };
          
          set({ 
            generatedRecipe,
            isLoading: false 
          });
        } catch (error) {
          console.error('Error generating recipe:', error);
          set({ 
            error: error instanceof Error ? error.message : 'An unknown error occurred',
            isLoading: false 
          });
        }
      },
      
      saveRecipe: (recipe: GeneratedRecipe) => {
        const { savedRecipes } = get();
        set({ 
          savedRecipes: [recipe, ...savedRecipes].slice(0, 20) // Keep only the 20 most recent recipes
        });
      },
      
      clearError: () => set({ error: null, generatedRecipe: null }),
      
      setRecipeLanguage: (language: string) => set({ recipeLanguage: language }),
    }),
    {
      name: 'ai-recipe-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        savedRecipes: state.savedRecipes,
        recipeLanguage: state.recipeLanguage,
      }),
    }
  )
);

// Initialize recipe language from app language
export const initializeRecipeLanguage = () => {
  const { language } = useLanguageStore.getState();
  const { recipeLanguage, setRecipeLanguage } = useAIStore.getState();
  
  // Only set if not already set (first time)
  if (recipeLanguage === 'en' && language !== 'en') {
    setRecipeLanguage(language);
  }
};