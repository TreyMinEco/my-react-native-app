import React, { useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Platform,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useLanguageStore } from "@/store/language-store";
import { Button } from "@/components/ui/Button";
import { CategoryPill } from "@/components/ui/CategoryPill";
import { cuisines, dietaryTags, mealTypes, cookingTimes, difficulties } from "@/mocks/categories";
import { X } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { t } from "@/constants/translations";

export default function FilterScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { filters, setFilters } = useRecipeStore();
  
  const [selectedMealTypes, setSelectedMealTypes] = useState<string[]>(
    filters.mealType?.map(m => m) || []
  );
  
  const [selectedCuisines, setSelectedCuisines] = useState<string[]>(
    filters.cuisine?.map(c => c) || []
  );
  
  const [selectedDietaryTags, setSelectedDietaryTags] = useState<string[]>(
    filters.dietaryTags?.map(d => d) || []
  );
  
  const [selectedCookingTime, setSelectedCookingTime] = useState<string | null>(
    filters.maxCookTime ? filters.maxCookTime.toString() : null
  );
  
  const [selectedDifficulties, setSelectedDifficulties] = useState<string[]>(
    filters.difficulty?.map(d => d) || []
  );

  const handleMealTypePress = (mealType: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedMealTypes.includes(mealType)) {
      setSelectedMealTypes(selectedMealTypes.filter(m => m !== mealType));
    } else {
      setSelectedMealTypes([...selectedMealTypes, mealType]);
    }
  };

  const handleCuisinePress = (cuisine: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedCuisines.includes(cuisine)) {
      setSelectedCuisines(selectedCuisines.filter(c => c !== cuisine));
    } else {
      setSelectedCuisines([...selectedCuisines, cuisine]);
    }
  };

  const handleDietaryTagPress = (tag: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedDietaryTags.includes(tag)) {
      setSelectedDietaryTags(selectedDietaryTags.filter(t => t !== tag));
    } else {
      setSelectedDietaryTags([...selectedDietaryTags, tag]);
    }
  };

  const handleCookingTimePress = (time: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedCookingTime === time) {
      setSelectedCookingTime(null);
    } else {
      setSelectedCookingTime(time);
    }
  };

  const handleDifficultyPress = (difficulty: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedDifficulties.includes(difficulty)) {
      setSelectedDifficulties(selectedDifficulties.filter(d => d !== difficulty));
    } else {
      setSelectedDifficulties([...selectedDifficulties, difficulty]);
    }
  };

  const handleApplyFilters = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    const newFilters: any = {};
    
    if (selectedMealTypes.length > 0) {
      newFilters.mealType = selectedMealTypes as any[];
    }
    
    if (selectedCuisines.length > 0) {
      newFilters.cuisine = selectedCuisines as any[];
    }
    
    if (selectedDietaryTags.length > 0) {
      newFilters.dietaryTags = selectedDietaryTags as any[];
    }
    
    if (selectedCookingTime) {
      newFilters.maxCookTime = parseInt(selectedCookingTime);
    }
    
    if (selectedDifficulties.length > 0) {
      newFilters.difficulty = selectedDifficulties as any[];
    }
    
    setFilters(newFilters);
    router.back();
  };

  const handleResetFilters = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setSelectedMealTypes([]);
    setSelectedCuisines([]);
    setSelectedDietaryTags([]);
    setSelectedCookingTime(null);
    setSelectedDifficulties([]);
  };

  const hasActiveFilters = 
    selectedMealTypes.length > 0 ||
    selectedCuisines.length > 0 ||
    selectedDietaryTags.length > 0 ||
    selectedCookingTime !== null ||
    selectedDifficulties.length > 0;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: t('filters', language),
          headerRight: () => (
            <TouchableOpacity 
              style={styles.closeButton} 
              onPress={() => router.back()}
            >
              <X size={24} color={themeColors.text} />
            </TouchableOpacity>
          ),
        }} 
      />
      
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('mealType', language)}
            </Text>
            {selectedMealTypes.length > 0 && (
              <TouchableOpacity onPress={() => setSelectedMealTypes([])}>
                <Text style={[styles.clearText, { color: themeColors.primary }]}>
                  {t('clear', language)}
                </Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.pillsContainer}>
            {mealTypes && mealTypes.map((mealType) => (
              <CategoryPill 
                key={mealType.id}
                label={mealType.name}
                isSelected={selectedMealTypes.includes(mealType.id)}
                onPress={() => handleMealTypePress(mealType.id)}
              />
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('cuisine', language)}
            </Text>
            {selectedCuisines.length > 0 && (
              <TouchableOpacity onPress={() => setSelectedCuisines([])}>
                <Text style={[styles.clearText, { color: themeColors.primary }]}>
                  {t('clear', language)}
                </Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.pillsContainer}>
            {cuisines && cuisines.map((cuisine) => (
              <CategoryPill 
                key={cuisine.id}
                label={cuisine.flag ? `${cuisine.flag} ${cuisine.name}` : cuisine.name}
                isSelected={selectedCuisines.includes(cuisine.id)}
                onPress={() => handleCuisinePress(cuisine.id)}
              />
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('dietaryPreferences', language)}
            </Text>
            {selectedDietaryTags.length > 0 && (
              <TouchableOpacity onPress={() => setSelectedDietaryTags([])}>
                <Text style={[styles.clearText, { color: themeColors.primary }]}>
                  {t('clear', language)}
                </Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.pillsContainer}>
            {dietaryTags && dietaryTags.map((tag) => (
              <CategoryPill 
                key={tag.id}
                label={tag.name}
                isSelected={selectedDietaryTags.includes(tag.id)}
                onPress={() => handleDietaryTagPress(tag.id)}
              />
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('cookingTime', language)}
            </Text>
            {selectedCookingTime && (
              <TouchableOpacity onPress={() => setSelectedCookingTime(null)}>
                <Text style={[styles.clearText, { color: themeColors.primary }]}>
                  {t('clear', language)}
                </Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.pillsContainer}>
            {cookingTimes && cookingTimes.map((time) => (
              <CategoryPill 
                key={time.id}
                label={time.name}
                isSelected={selectedCookingTime === time.id}
                onPress={() => handleCookingTimePress(time.id)}
              />
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('difficulty', language)}
            </Text>
            {selectedDifficulties.length > 0 && (
              <TouchableOpacity onPress={() => setSelectedDifficulties([])}>
                <Text style={[styles.clearText, { color: themeColors.primary }]}>
                  {t('clear', language)}
                </Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.pillsContainer}>
            {difficulties && difficulties.map((difficulty) => (
              <CategoryPill 
                key={difficulty.id}
                label={difficulty.name}
                isSelected={selectedDifficulties.includes(difficulty.id)}
                onPress={() => handleDifficultyPress(difficulty.id)}
              />
            ))}
          </View>
        </View>
      </ScrollView>
      
      <View style={[styles.footer, { borderTopColor: themeColors.border }]}>
        <Button
          title={t('reset', language)}
          onPress={handleResetFilters}
          variant="outline"
          style={styles.resetButton}
          disabled={!hasActiveFilters}
        />
        <Button
          title={t('applyFilters', language)}
          onPress={handleApplyFilters}
          style={styles.applyButton}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  closeButton: {
    padding: 8,
    marginRight: 8,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  clearText: {
    fontSize: 14,
  },
  pillsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  footer: {
    flexDirection: "row",
    padding: 16,
    borderTopWidth: 1,
    gap: 12,
  },
  resetButton: {
    flex: 1,
  },
  applyButton: {
    flex: 2,
  },
});