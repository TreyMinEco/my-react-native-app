import React, { useState, useEffect } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Platform,
  Modal,
  FlatList,
  Alert,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useUserStore } from "@/store/user-store";
import { useRecipeStore } from "@/store/recipe-store";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { MealPlanDay } from "@/components/ui/MealPlanDay";
import { RecipeCard } from "@/components/ui/RecipeCard";
import { SearchBar } from "@/components/ui/SearchBar";
import { Calendar, Plus, X, Trash2 } from "lucide-react-native";
import * as Haptics from "expo-haptics";

export default function MealPlanEditScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const { 
    mealPlans,
    addMealPlan,
    updateMealPlan,
    removeMealPlan,
    addRecipeToMealPlan,
    removeRecipeFromMealPlan
  } = useUserStore();
  
  const { recipes } = useRecipeStore();
  
  const [activePlanId, setActivePlanId] = useState(mealPlans[0]?.id || "");
  const [showAddPlanModal, setShowAddPlanModal] = useState(false);
  const [newPlanName, setNewPlanName] = useState("");
  
  const [showAddRecipeModal, setShowAddRecipeModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedMealType, setSelectedMealType] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Create a default meal plan if none exists
  useEffect(() => {
    if (mealPlans.length === 0) {
      setShowAddPlanModal(true);
    } else if (!activePlanId && mealPlans.length > 0) {
      setActivePlanId(mealPlans[0].id);
    }
  }, [mealPlans]);
  
  const activePlan = mealPlans.find(plan => plan.id === activePlanId);

  const handleAddPlan = () => {
    if (!newPlanName.trim()) return;
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    
    const newPlanId = Math.random().toString(36).substring(2, 9);
    
    addMealPlan({
      name: newPlanName.trim(),
      days: [
        { date: today },
        { date: tomorrow },
      ],
    });
    
    setNewPlanName("");
    setShowAddPlanModal(false);
    
    // Set the new plan as active
    setTimeout(() => {
      const newPlan = mealPlans.find(p => p.name === newPlanName.trim());
      if (newPlan) {
        setActivePlanId(newPlan.id);
      } else if (mealPlans.length > 0) {
        setActivePlanId(mealPlans[mealPlans.length - 1].id);
      }
    }, 100);
  };

  const handleDeletePlan = () => {
    if (!activePlanId) return;
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    const confirmDelete = () => {
      removeMealPlan(activePlanId);
      if (mealPlans.length > 1) {
        const nextPlan = mealPlans.find(p => p.id !== activePlanId);
        if (nextPlan) {
          setActivePlanId(nextPlan.id);
        }
      } else {
        setActivePlanId("");
      }
    };
    
    if (Platform.OS === 'web') {
      if (confirm("Are you sure you want to delete this meal plan?")) {
        confirmDelete();
      }
    } else {
      Alert.alert(
        "Delete Meal Plan",
        "Are you sure you want to delete this meal plan?",
        [
          { text: "Cancel", style: "cancel" },
          { 
            text: "Delete", 
            style: "destructive",
            onPress: confirmDelete
          }
        ]
      );
    }
  };

  const handleAddMeal = (date: string, mealType: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    setSelectedDate(date);
    setSelectedMealType(mealType);
    setShowAddRecipeModal(true);
  };

  const handleAddRecipeToMealPlan = (recipeId: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (activePlanId && selectedDate && selectedMealType) {
      addRecipeToMealPlan(activePlanId, selectedDate, selectedMealType, recipeId);
      setShowAddRecipeModal(false);
    }
  };

  const handleRemoveRecipeFromMealPlan = (date: string, mealType: string, recipeId: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (activePlanId) {
      removeRecipeFromMealPlan(activePlanId, date, mealType, recipeId);
    }
  };

  const filteredRecipes = searchQuery
    ? recipes.filter(recipe => 
        recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recipes;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: "Meal Planner",
          headerRight: () => (
            activePlanId ? (
              <TouchableOpacity 
                style={styles.headerButton} 
                onPress={handleDeletePlan}
              >
                <Trash2 size={20} color={themeColors.error} />
              </TouchableOpacity>
            ) : null
          ),
        }} 
      />
      
      <View style={styles.header}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.planSelector}
        >
          {mealPlans.map((plan) => (
            <TouchableOpacity
              key={plan.id}
              style={[
                styles.planTab,
                activePlanId === plan.id && [
                  styles.activePlanTab,
                  { borderBottomColor: themeColors.primary }
                ]
              ]}
              onPress={() => setActivePlanId(plan.id)}
            >
              <Text
                style={[
                  styles.planTabText,
                  {
                    color: activePlanId === plan.id
                      ? themeColors.primary
                      : themeColors.subtext
                  }
                ]}
              >
                {plan.name}
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={styles.addPlanButton}
            onPress={() => setShowAddPlanModal(true)}
          >
            <Plus size={20} color={themeColors.primary} />
          </TouchableOpacity>
        </ScrollView>
      </View>
      
      {activePlan ? (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          {activePlan.days.map((day) => (
            <MealPlanDay
              key={day.date}
              day={day}
              onAddMeal={(mealType) => handleAddMeal(day.date, mealType)}
              onRemoveMeal={(mealType, recipeId) => 
                handleRemoveRecipeFromMealPlan(day.date, mealType, recipeId)
              }
              onViewRecipe={(recipeId) => router.push(`/recipe?id=${recipeId}`)}
            />
          ))}
          
          <Button
            title="Add Day"
            onPress={() => {
              // Add a new day to the meal plan
              const lastDay = activePlan.days[activePlan.days.length - 1];
              const lastDate = new Date(lastDay.date);
              const nextDate = new Date(lastDate);
              nextDate.setDate(nextDate.getDate() + 1);
              
              updateMealPlan(activePlanId, {
                days: [
                  ...activePlan.days,
                  { date: nextDate.toISOString().split('T')[0] }
                ]
              });
            }}
            variant="outline"
            icon={<Calendar size={16} color={themeColors.primary} />}
            style={styles.addDayButton}
          />
        </ScrollView>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={[styles.emptyTitle, { color: themeColors.text }]}>
            No Meal Plans
          </Text>
          <Text style={[styles.emptyText, { color: themeColors.subtext }]}>
            Create a meal plan to start planning your meals
          </Text>
          <Button
            title="Create Meal Plan"
            onPress={() => setShowAddPlanModal(true)}
            icon={<Plus size={16} color="white" />}
            style={styles.createPlanButton}
          />
        </View>
      )}
      
      {/* Add Plan Modal */}
      <Modal
        visible={showAddPlanModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => {
          if (mealPlans.length > 0) {
            setShowAddPlanModal(false);
          }
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: themeColors.background }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: themeColors.text }]}>
                Create Meal Plan
              </Text>
              {mealPlans.length > 0 && (
                <TouchableOpacity onPress={() => setShowAddPlanModal(false)}>
                  <X size={24} color={themeColors.text} />
                </TouchableOpacity>
              )}
            </View>
            
            <Input
              label="Plan Name"
              placeholder="e.g., This Week, Keto Plan, etc."
              value={newPlanName}
              onChangeText={setNewPlanName}
            />
            
            <Button
              title="Create Plan"
              onPress={handleAddPlan}
              disabled={!newPlanName.trim()}
              style={styles.createButton}
            />
          </View>
        </View>
      </Modal>
      
      {/* Add Recipe Modal */}
      <Modal
        visible={showAddRecipeModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowAddRecipeModal(false)}
      >
        <View style={[styles.recipeModalContainer, { backgroundColor: themeColors.background }]}>
          <View style={styles.recipeModalHeader}>
            <Text style={[styles.recipeModalTitle, { color: themeColors.text }]}>
              Add Recipe to {selectedMealType}
            </Text>
            <TouchableOpacity onPress={() => setShowAddRecipeModal(false)}>
              <X size={24} color={themeColors.text} />
            </TouchableOpacity>
          </View>
          
          <SearchBar
            placeholder="Search recipes..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            style={{ paddingHorizontal: 16, marginBottom: 8 }}
          />
          
          <FlatList
            data={filteredRecipes}
            renderItem={({ item }) => (
              <TouchableOpacity 
                style={styles.recipeItem}
                onPress={() => handleAddRecipeToMealPlan(item.id)}
              >
                <RecipeCard recipe={item} variant="horizontal" />
              </TouchableOpacity>
            )}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.recipeList}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 8,
  },
  headerButton: {
    padding: 8,
    marginRight: 8,
  },
  planSelector: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  planTab: {
    paddingVertical: 12,
    marginRight: 24,
  },
  activePlanTab: {
    borderBottomWidth: 2,
  },
  planTabText: {
    fontSize: 16,
    fontWeight: "600",
  },
  addPlanButton: {
    padding: 8,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "600",
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 24,
  },
  createPlanButton: {
    minWidth: 200,
  },
  addDayButton: {
    marginTop: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "80%",
    borderRadius: 12,
    padding: 24,
    ...Platform.select({
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "600",
  },
  createButton: {
    marginTop: 8,
  },
  recipeModalContainer: {
    flex: 1,
    paddingTop: 48,
  },
  recipeModalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  recipeModalTitle: {
    fontSize: 20,
    fontWeight: "600",
  },
  recipeList: {
    padding: 16,
  },
  recipeItem: {
    marginBottom: 16,
  },
});