import React, { useState, useEffect } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useLanguageStore } from "@/store/language-store";
import { SearchBar } from "@/components/ui/SearchBar";
import { RecipeCard } from "@/components/ui/RecipeCard";
import { CategoryPill } from "@/components/ui/CategoryPill";
import { Filter } from "lucide-react-native";
import { cuisines, dietaryTags, mealTypes } from "@/mocks/categories";
import * as Haptics from "expo-haptics";
import { t } from "@/constants/translations";

export default function SearchScreen() {
  const params = useLocalSearchParams();
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { 
    searchQuery: globalSearchQuery, 
    setSearchQuery, 
    getFilteredRecipes,
    setFilters,
    filters,
  } = useRecipeStore();
  
  const [searchQuery, setLocalSearchQuery] = useState(globalSearchQuery);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    params.category as string || null
  );
  
  useEffect(() => {
    if (params.category) {
      setSelectedCategory(params.category as string);
      
      // Apply category filter
      const category = params.category as string;
      
      // Check if it's a meal type
      const mealType = mealTypes && mealTypes.find(m => m.id === category);
      if (mealType) {
        setFilters({ ...filters, mealType: [category as any] });
        return;
      }
      
      // Check if it's a cuisine
      const cuisine = cuisines && cuisines.find(c => c.id === category);
      if (cuisine) {
        setFilters({ ...filters, cuisine: [category as any] });
        return;
      }
      
      // Check if it's a dietary tag
      const dietaryTag = dietaryTags && dietaryTags.find(d => d.id === category);
      if (dietaryTag) {
        setFilters({ ...filters, dietaryTags: [category as any] });
        return;
      }
    }
  }, [params.category]);

  const handleSearch = () => {
    setSearchQuery(searchQuery);
  };

  const handleVoiceSearch = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    // Voice search functionality would be implemented here
    console.log("Voice search");
  };

  const handleCameraSearch = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    // Camera search functionality would be implemented here
    console.log("Camera search");
  };

  const handleFilterPress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push("/filter");
  };

  const handleCategoryPress = (category: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedCategory === category) {
      setSelectedCategory(null);
      setFilters({});
    } else {
      setSelectedCategory(category);
      
      // Apply category filter
      // Check if it's a meal type
      const mealType = mealTypes && mealTypes.find(m => m.id === category);
      if (mealType) {
        setFilters({ ...filters, mealType: [category as any] });
        return;
      }
      
      // Check if it's a cuisine
      const cuisine = cuisines && cuisines.find(c => c.id === category);
      if (cuisine) {
        setFilters({ ...filters, cuisine: [category as any] });
        return;
      }
      
      // Check if it's a dietary tag
      const dietaryTag = dietaryTags && dietaryTags.find(d => d.id === category);
      if (dietaryTag) {
        setFilters({ ...filters, dietaryTags: [category as any] });
        return;
      }
    }
  };

  const filteredRecipes = getFilteredRecipes() || [];

  // Helper function to get category name
  const getCategoryName = (categoryId: string) => {
    if (!categoryId) return "";
    
    const mealType = mealTypes && mealTypes.find(m => m.id === categoryId);
    if (mealType) return mealType.name;
    
    const cuisine = cuisines && cuisines.find(c => c.id === categoryId);
    if (cuisine) return cuisine.name;
    
    const dietaryTag = dietaryTags && dietaryTags.find(d => d.id === categoryId);
    if (dietaryTag) return dietaryTag.name;
    
    return categoryId;
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: t('search', language),
          headerRight: () => (
            <TouchableOpacity 
              style={styles.filterButton} 
              onPress={handleFilterPress}
            >
              <Filter size={24} color={themeColors.text} />
            </TouchableOpacity>
          ),
        }} 
      />
      
      <View style={styles.searchContainer}>
        <SearchBar 
          placeholder={t('searchForRecipes', language)}
          value={searchQuery}
          onChangeText={setLocalSearchQuery}
          onSubmit={handleSearch}
          onVoiceSearch={handleVoiceSearch}
          onCameraSearch={handleCameraSearch}
          autoFocus
        />
      </View>
      
      {selectedCategory && (
        <View style={styles.selectedCategoryContainer}>
          <Text style={[styles.selectedCategoryLabel, { color: themeColors.subtext }]}>
            {t('filteredBy', language)}:
          </Text>
          <CategoryPill 
            label={getCategoryName(selectedCategory)}
            isSelected={true}
            onPress={() => handleCategoryPress(selectedCategory)}
          />
        </View>
      )}
      
      <FlatList
        data={filteredRecipes}
        renderItem={({ item }) => (
          <View style={styles.recipeItem}>
            <RecipeCard 
              recipe={item} 
              variant="horizontal" 
              onPress={() => router.push({
                pathname: '/recipe',
                params: { id: item.id }
              })}
            />
          </View>
        )}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyTitle, { color: themeColors.text }]}>
              {t('noRecipesFound', language)}
            </Text>
            <Text style={[styles.emptyText, { color: themeColors.subtext }]}>
              {t('tryAdjustingSearch', language)}
            </Text>
          </View>
        }
        ListHeaderComponent={
          filteredRecipes.length > 0 ? (
            <Text style={[styles.resultsText, { color: themeColors.text }]}>
              {filteredRecipes.length} {filteredRecipes.length === 1 
                ? t('recipe', language) 
                : t('recipes', language)} {t('found', language)}
            </Text>
          ) : null
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  filterButton: {
    padding: 8,
    marginRight: 8,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  selectedCategoryContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 8,
  },
  selectedCategoryLabel: {
    fontSize: 14,
  },
  listContent: {
    padding: 16,
    paddingTop: 8,
  },
  recipeItem: {
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
  },
  resultsText: {
    fontSize: 14,
    marginBottom: 16,
  },
});