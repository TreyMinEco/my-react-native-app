import React, { useState, useEffect } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Platform,
  FlatList,
  ActivityIndicator,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useLanguageStore } from "@/store/language-store";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { RecipeCard } from "@/components/ui/RecipeCard";
import { ChefHat, Plus, X, Search, RefreshCw } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { t } from "@/constants/translations";
import { normalize, responsiveFontSize } from "@/constants/layout";
import { Recipe } from "@/types/recipe";

// Common ingredients suggestions
const COMMON_INGREDIENTS = [
  "chicken", "beef", "pork", "salmon", "shrimp",
  "rice", "pasta", "potatoes", "bread", "flour",
  "tomatoes", "onions", "garlic", "bell peppers", "carrots",
  "broccoli", "spinach", "lettuce", "mushrooms", "zucchini",
  "cheese", "eggs", "milk", "butter", "yogurt",
  "olive oil", "soy sauce", "vinegar", "lemon", "herbs"
];

export default function IngredientsSearchScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { getRecipesByIngredients } = useRecipeStore();
  
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [currentIngredient, setCurrentIngredient] = useState("");
  const [searchResults, setSearchResults] = useState<Recipe[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Filter suggestions based on current input
  useEffect(() => {
    if (currentIngredient.trim().length > 0) {
      const filtered = COMMON_INGREDIENTS.filter(
        ing => ing.toLowerCase().includes(currentIngredient.toLowerCase())
      ).slice(0, 5); // Limit to 5 suggestions
      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setShowSuggestions(false);
    }
  }, [currentIngredient]);

  const handleAddIngredient = (ingredient = currentIngredient) => {
    const trimmedIngredient = ingredient.trim();
    if (trimmedIngredient && !ingredients.includes(trimmedIngredient)) {
      if (Platform.OS !== 'web') {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
      setIngredients([...ingredients, trimmedIngredient]);
      setCurrentIngredient("");
      setShowSuggestions(false);
    }
  };

  const handleRemoveIngredient = (index: number) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    const newIngredients = [...ingredients];
    newIngredients.splice(index, 1);
    setIngredients(newIngredients);
  };

  const handleSearch = () => {
    if (ingredients.length === 0) return;
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setIsSearching(true);
    
    // Simulate a delay for better UX
    setTimeout(() => {
      const results = getRecipesByIngredients(ingredients) || [];
      setSearchResults(results);
      setHasSearched(true);
      setIsSearching(false);
    }, 800);
  };

  const handleClearAll = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setIngredients([]);
    setSearchResults([]);
    setHasSearched(false);
  };

  const handleSelectSuggestion = (suggestion: string) => {
    handleAddIngredient(suggestion);
  };

  const renderSuggestions = () => {
    if (!showSuggestions) return null;
    
    return (
      <View style={[styles.suggestionsContainer, { backgroundColor: themeColors.card, borderColor: themeColors.border }]}>
        {suggestions.map((suggestion, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.suggestionItem, index < suggestions.length - 1 && { borderBottomColor: themeColors.border, borderBottomWidth: 1 }]}
            onPress={() => handleSelectSuggestion(suggestion)}
          >
            <Text style={[styles.suggestionText, { color: themeColors.text }]}>{suggestion}</Text>
            <Plus size={normalize(16)} color={themeColors.primary} />
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: t('cookWithIngredients', language),
        }} 
      />
      
      <ScrollView 
        showsVerticalScrollIndicator={false} 
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.iconContainer}>
          <View style={[
            styles.iconCircle, 
            { backgroundColor: 'rgba(76, 175, 80, 0.1)' }
          ]}>
            <ChefHat size={normalize(32)} color={colors.light.secondary} />
          </View>
        </View>
        
        <Text style={[styles.title, { color: themeColors.text }]}>
          {t('whatsInYourKitchen', language) || "What's in Your Kitchen?"}
        </Text>
        <Text style={[styles.description, { color: themeColors.subtext }]}>
          {t('enterIngredientsPrompt', language) || "Enter ingredients you have on hand, and we'll find recipes you can make."}
        </Text>
        
        <View style={styles.inputContainer}>
          <Input
            placeholder={t('enterIngredient', language) || "Enter an ingredient"}
            value={currentIngredient}
            onChangeText={setCurrentIngredient}
            onSubmitEditing={() => handleAddIngredient()}
            returnKeyType="done"
            containerStyle={styles.input}
          />
          <TouchableOpacity 
            style={[
              styles.addButton, 
              { 
                backgroundColor: themeColors.secondary,
                opacity: !currentIngredient.trim() ? 0.5 : 1,
              }
            ]}
            onPress={() => handleAddIngredient()}
            disabled={!currentIngredient.trim()}
          >
            <Plus size={normalize(20)} color="white" />
          </TouchableOpacity>
        </View>
        
        {renderSuggestions()}
        
        {ingredients.length > 0 && (
          <>
            <View style={styles.ingredientsList}>
              {ingredients.map((ingredient, index) => (
                <View 
                  key={index} 
                  style={[
                    styles.ingredientItem, 
                    { 
                      backgroundColor: themeColors.card,
                      borderColor: themeColors.border,
                    }
                  ]}
                >
                  <Text style={[styles.ingredientText, { color: themeColors.text }]}>
                    {ingredient}
                  </Text>
                  <TouchableOpacity 
                    onPress={() => handleRemoveIngredient(index)}
                    hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
                  >
                    <X size={normalize(16)} color={themeColors.subtext} />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
            
            <View style={styles.buttonContainer}>
              <Button
                title={t('clearAll', language) || "Clear All"}
                onPress={handleClearAll}
                variant="outline"
                style={styles.clearButton}
              />
              <Button
                title={t('findRecipes', language) || "Find Recipes"}
                onPress={handleSearch}
                icon={<Search size={normalize(16)} color="white" />}
                style={[styles.searchButton, { backgroundColor: themeColors.secondary }]}
                isLoading={isSearching}
              />
            </View>
          </>
        )}
        
        {hasSearched && !isSearching && (
          <View style={styles.resultsContainer}>
            <Text style={[styles.resultsTitle, { color: themeColors.text }]}>
              {searchResults.length > 0 
                ? t('foundRecipesCount', language, { count: searchResults.length }) || `Found ${searchResults.length} recipes` 
                : t('noRecipesFound', language) || "No recipes found"}
            </Text>
            
            {searchResults.length > 0 ? (
              <FlatList
                data={searchResults}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.recipeCard}>
                    <RecipeCard
                      recipe={item}
                      onPress={() => router.push({ pathname: '/recipe', params: { id: item.id } })}
                    />
                  </View>
                )}
                horizontal={false}
                showsVerticalScrollIndicator={false}
                scrollEnabled={false}
                ItemSeparatorComponent={() => <View style={{ height: normalize(16) }} />}
              />
            ) : (
              <View style={styles.noResultsContainer}>
                <Text style={[styles.noResultsText, { color: themeColors.subtext }]}>
                  {t('noRecipesFoundTip', language) || "Try adding more ingredients or removing some specific ones."}
                </Text>
                <Button
                  title={t('tryDifferentIngredients', language) || "Try Different Ingredients"}
                  onPress={handleClearAll}
                  icon={<RefreshCw size={normalize(16)} color="white" />}
                  style={styles.tryAgainButton}
                />
              </View>
            )}
          </View>
        )}
        
        {!hasSearched && ingredients.length === 0 && (
          <View style={styles.suggestionsSection}>
            <Text style={[styles.suggestionsTitle, { color: themeColors.text }]}>
              {t('popularIngredients', language) || "Popular Ingredients"}
            </Text>
            <View style={styles.popularIngredientsContainer}>
              {COMMON_INGREDIENTS.slice(0, 10).map((ingredient, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.popularIngredient, { backgroundColor: themeColors.card, borderColor: themeColors.border }]}
                  onPress={() => handleAddIngredient(ingredient)}
                >
                  <Text style={[styles.popularIngredientText, { color: themeColors.text }]}>
                    {ingredient}
                  </Text>
                  <Plus size={normalize(14)} color={themeColors.primary} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: normalize(16),
    paddingBottom: normalize(32),
  },
  iconContainer: {
    alignItems: "center",
    marginVertical: normalize(24),
  },
  iconCircle: {
    width: normalize(80),
    height: normalize(80),
    borderRadius: normalize(40),
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: responsiveFontSize(24),
    fontWeight: "700",
    textAlign: "center",
    marginBottom: normalize(8),
  },
  description: {
    fontSize: responsiveFontSize(16),
    textAlign: "center",
    marginBottom: normalize(24),
    lineHeight: normalize(22),
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: normalize(8),
    marginBottom: normalize(8),
  },
  input: {
    flex: 1,
    marginBottom: 0,
  },
  addButton: {
    width: normalize(48),
    height: normalize(48),
    borderRadius: normalize(24),
    justifyContent: "center",
    alignItems: "center",
  },
  suggestionsContainer: {
    borderWidth: 1,
    borderRadius: normalize(8),
    marginBottom: normalize(16),
    overflow: 'hidden',
  },
  suggestionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: normalize(12),
    paddingHorizontal: normalize(16),
  },
  suggestionText: {
    fontSize: responsiveFontSize(14),
  },
  ingredientsList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: normalize(8),
    marginBottom: normalize(16),
  },
  ingredientItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: normalize(12),
    paddingVertical: normalize(8),
    borderRadius: normalize(16),
    borderWidth: 1,
    gap: normalize(8),
  },
  ingredientText: {
    fontSize: responsiveFontSize(14),
  },
  buttonContainer: {
    flexDirection: "row",
    gap: normalize(12),
    marginBottom: normalize(24),
  },
  clearButton: {
    flex: 1,
  },
  searchButton: {
    flex: 2,
  },
  resultsContainer: {
    marginTop: normalize(8),
  },
  resultsTitle: {
    fontSize: responsiveFontSize(18),
    fontWeight: "600",
    marginBottom: normalize(16),
  },
  noResultsContainer: {
    alignItems: 'center',
    paddingVertical: normalize(24),
  },
  noResultsText: {
    fontSize: responsiveFontSize(16),
    textAlign: "center",
    marginBottom: normalize(16),
    lineHeight: normalize(22),
  },
  tryAgainButton: {
    minWidth: normalize(220),
  },
  recipeCard: {
    marginBottom: normalize(16),
  },
  suggestionsSection: {
    marginTop: normalize(24),
  },
  suggestionsTitle: {
    fontSize: responsiveFontSize(18),
    fontWeight: "600",
    marginBottom: normalize(12),
  },
  popularIngredientsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: normalize(8),
  },
  popularIngredient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: normalize(12),
    paddingVertical: normalize(8),
    borderRadius: normalize(16),
    borderWidth: 1,
    gap: normalize(6),
  },
  popularIngredientText: {
    fontSize: responsiveFontSize(14),
  },
});