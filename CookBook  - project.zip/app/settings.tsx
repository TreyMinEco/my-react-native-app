import React, { useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Platform,
  Switch,
  Alert,
  FlatList,
  Modal,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useUserStore } from "@/store/user-store";
import { useLanguageStore } from "@/store/language-store";
import { languages, Language } from "@/constants/languages";
import { t } from "@/constants/translations";
import { 
  Moon, 
  Sun, 
  Globe, 
  Bell, 
  Lock, 
  HelpCircle, 
  FileText, 
  MessageSquare, 
  Star, 
  Share, 
  ChevronRight,
  Check,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { normalize, responsiveFontSize } from "@/constants/layout";

export default function SettingsScreen() {
  const router = useRouter();
  const { theme, setTheme, getActiveTheme } = useThemeStore();
  const activeTheme = getActiveTheme();
  const themeColors = colors[activeTheme];
  
  const { preferences, updatePreferences } = useUserStore();
  const { language, setLanguage } = useLanguageStore();
  
  const [languageModalVisible, setLanguageModalVisible] = useState(false);

  const handleThemeToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (theme === 'light') {
      setTheme('dark');
    } else if (theme === 'dark') {
      setTheme('light');
    } else {
      // If system, set to explicit light/dark based on current appearance
      setTheme(activeTheme === 'light' ? 'dark' : 'light');
    }
  };

  const handleMeasurementSystemToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    updatePreferences({
      measurementSystem: preferences.measurementSystem === 'metric' ? 'imperial' : 'metric',
    });
  };

  const handleNotificationsToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    updatePreferences({
      notificationsEnabled: !preferences.notificationsEnabled,
    });
  };

  const handlePushNotificationToggle = (type: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    updatePreferences({
      pushNotifications: {
        ...preferences.pushNotifications,
        [type]: !preferences.pushNotifications[type as keyof typeof preferences.pushNotifications],
      },
    });
  };

  const handleLanguageSelect = (languageCode: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setLanguage(languageCode);
    setLanguageModalVisible(false);
  };

  const getLanguageDisplayName = () => {
    const selectedLanguage = languages.find(lang => lang.id === language);
    return selectedLanguage ? selectedLanguage.nativeName : 'English';
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: t('settings', language),
        }} 
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('appearance', language)}
          </Text>
          
          <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
            <View style={styles.settingLeft}>
              {activeTheme === 'dark' ? (
                <Moon size={normalize(20)} color={themeColors.text} />
              ) : (
                <Sun size={normalize(20)} color={themeColors.text} />
              )}
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {activeTheme === 'dark' ? t('darkMode', language) : t('lightMode', language)}
              </Text>
            </View>
            <Switch
              value={activeTheme === 'dark'}
              onValueChange={handleThemeToggle}
              trackColor={{ false: '#767577', true: themeColors.primary }}
              thumbColor={'#f4f3f4'}
            />
          </View>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
            onPress={() => setLanguageModalVisible(true)}
          >
            <View style={styles.settingLeft}>
              <Globe size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('language', language)}
              </Text>
            </View>
            <View style={styles.settingRight}>
              <Text style={[styles.settingValue, { color: themeColors.subtext }]}>
                {getLanguageDisplayName()}
              </Text>
              <ChevronRight size={normalize(20)} color={themeColors.subtext} />
            </View>
          </TouchableOpacity>
          
          <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
            <View style={styles.settingLeft}>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('measurementSystem', language)}
              </Text>
            </View>
            <View style={styles.settingRight}>
              <Text style={[styles.settingValue, { color: themeColors.subtext }]}>
                {preferences.measurementSystem === 'metric' 
                  ? t('metric', language) 
                  : t('imperial', language)}
              </Text>
              <Switch
                value={preferences.measurementSystem === 'metric'}
                onValueChange={handleMeasurementSystemToggle}
                trackColor={{ false: '#767577', true: themeColors.primary }}
                thumbColor={'#f4f3f4'}
              />
            </View>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('notifications', language)}
          </Text>
          
          <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
            <View style={styles.settingLeft}>
              <Bell size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('enableNotifications', language)}
              </Text>
            </View>
            <Switch
              value={preferences.notificationsEnabled}
              onValueChange={handleNotificationsToggle}
              trackColor={{ false: '#767577', true: themeColors.primary }}
              thumbColor={'#f4f3f4'}
            />
          </View>
          
          {preferences.notificationsEnabled && (
            <>
              <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
                <View style={styles.settingLeft}>
                  <Text style={[styles.settingText, { color: themeColors.text }]}>
                    {t('newRecipes', language)}
                  </Text>
                </View>
                <Switch
                  value={preferences.pushNotifications.newRecipes}
                  onValueChange={() => handlePushNotificationToggle('newRecipes')}
                  trackColor={{ false: '#767577', true: themeColors.primary }}
                  thumbColor={'#f4f3f4'}
                />
              </View>
              
              <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
                <View style={styles.settingLeft}>
                  <Text style={[styles.settingText, { color: themeColors.text }]}>
                    {t('mealReminders', language)}
                  </Text>
                </View>
                <Switch
                  value={preferences.pushNotifications.mealReminders}
                  onValueChange={() => handlePushNotificationToggle('mealReminders')}
                  trackColor={{ false: '#767577', true: themeColors.primary }}
                  thumbColor={'#f4f3f4'}
                />
              </View>
              
              <View style={[styles.settingItem, { borderBottomColor: themeColors.border }]}>
                <View style={styles.settingLeft}>
                  <Text style={[styles.settingText, { color: themeColors.text }]}>
                    {t('cookingTips', language)}
                  </Text>
                </View>
                <Switch
                  value={preferences.pushNotifications.tips}
                  onValueChange={() => handlePushNotificationToggle('tips')}
                  trackColor={{ false: '#767577', true: themeColors.primary }}
                  thumbColor={'#f4f3f4'}
                />
              </View>
            </>
          )}
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('privacyAndSecurity', language)}
          </Text>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <Lock size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('privacyPolicy', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <FileText size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('termsOfService', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('support', language)}
          </Text>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <HelpCircle size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('helpCenter', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <MessageSquare size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('contactUs', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <Star size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('rateTheApp', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: themeColors.border }]}
          >
            <View style={styles.settingLeft}>
              <Share size={normalize(20)} color={themeColors.text} />
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('shareTheApp', language)}
              </Text>
            </View>
            <ChevronRight size={normalize(20)} color={themeColors.subtext} />
          </TouchableOpacity>
        </View>
        
        <Text style={[styles.versionText, { color: themeColors.subtext }]}>
          {t('version', language)} 1.0.0
        </Text>
      </ScrollView>
      
      <Modal
        visible={languageModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setLanguageModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: themeColors.card }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: themeColors.text }]}>
                {t('language', language)}
              </Text>
              <TouchableOpacity 
                onPress={() => setLanguageModalVisible(false)}
                style={styles.closeButton}
              >
                <Text style={[styles.closeButtonText, { color: themeColors.primary }]}>
                  ✕
                </Text>
              </TouchableOpacity>
            </View>
            
            <FlatList
              data={languages}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.languageItem,
                    language === item.id && { backgroundColor: `${themeColors.primary}20` }
                  ]}
                  onPress={() => handleLanguageSelect(item.id)}
                >
                  <Text style={[styles.languageName, { color: themeColors.text }]}>
                    {item.nativeName}
                  </Text>
                  <Text style={[styles.languageNameEnglish, { color: themeColors.subtext }]}>
                    {item.name !== item.nativeName ? item.name : ''}
                  </Text>
                  {language === item.id && (
                    <Check size={normalize(18)} color={themeColors.primary} />
                  )}
                </TouchableOpacity>
              )}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.languageList}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    marginBottom: normalize(24),
  },
  sectionTitle: {
    fontSize: responsiveFontSize(18),
    fontWeight: "600",
    marginBottom: normalize(12),
    paddingHorizontal: normalize(16),
  },
  settingItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: normalize(16),
    paddingHorizontal: normalize(16),
    borderBottomWidth: 1,
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: normalize(12),
  },
  settingText: {
    fontSize: responsiveFontSize(16),
  },
  settingRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: normalize(8),
  },
  settingValue: {
    fontSize: responsiveFontSize(14),
  },
  versionText: {
    textAlign: "center",
    marginBottom: normalize(32),
    fontSize: responsiveFontSize(14),
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    borderTopLeftRadius: normalize(20),
    borderTopRightRadius: normalize(20),
    paddingTop: normalize(20),
    paddingBottom: normalize(40),
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: normalize(20),
    marginBottom: normalize(10),
  },
  modalTitle: {
    fontSize: responsiveFontSize(20),
    fontWeight: '600',
  },
  closeButton: {
    padding: normalize(8),
  },
  closeButtonText: {
    fontSize: responsiveFontSize(20),
    fontWeight: '600',
  },
  languageList: {
    paddingHorizontal: normalize(20),
  },
  languageItem: {
    paddingVertical: normalize(16),
    borderRadius: normalize(8),
    paddingHorizontal: normalize(12),
    marginVertical: normalize(4),
    flexDirection: 'row',
    alignItems: 'center',
  },
  languageName: {
    fontSize: responsiveFontSize(16),
    fontWeight: '500',
    flex: 1,
  },
  languageNameEnglish: {
    fontSize: responsiveFontSize(14),
    marginLeft: normalize(8),
  },
});