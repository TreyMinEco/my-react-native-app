import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Image,
  Platform,
  Share,
  Alert,
  KeyboardAvoidingView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useThemeStore } from '@/store/theme-store';
import { useLanguageStore } from '@/store/language-store';
import { useAIStore } from '@/store/ai-store';
import { colors } from '@/constants/colors';
import { normalize, responsiveFontSize } from '@/constants/layout';
import { t } from '@/constants/translations';
import { languages } from '@/constants/languages';
import { ChefHat, Clock, Share2, ArrowLeft, Check, Languages } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

export default function AIRecipeScreen() {
  const router = useRouter();
  const { theme, getActiveTheme } = useThemeStore();
  const activeTheme = getActiveTheme();
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { 
    generateRecipe, 
    generatedRecipe, 
    isLoading, 
    error, 
    clearError,
    saveRecipe,
    recipeLanguage,
    setRecipeLanguage,
  } = useAIStore();
  
  const [dishName, setDishName] = useState('');
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  
  // Reset state when navigating to this screen
  useEffect(() => {
    return () => {
      clearError();
    };
  }, []);
  
  const handleGenerateRecipe = async () => {
    if (!dishName.trim()) {
      Alert.alert(
        t('error', language),
        'Please enter a dish name',
        [{ text: 'OK' }]
      );
      return;
    }
    
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    
    await generateRecipe(dishName, recipeLanguage);
  };
  
  const handleSaveRecipe = () => {
    if (generatedRecipe) {
      saveRecipe(generatedRecipe);
      
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      
      Alert.alert(
        t('success', language),
        t('recipeSaved', language),
        [{ text: 'OK' }]
      );
    }
  };
  
  const handleShareRecipe = async () => {
    if (!generatedRecipe) return;
    
    try {
      let shareText = `${generatedRecipe.title}\n\n`;
      
      if (generatedRecipe.description) {
        shareText += `${generatedRecipe.description}\n\n`;
      }
      
      shareText += `${t('cookingTime', language)}: ${generatedRecipe.cookingTimeMinutes} ${t('mins', language)}\n`;
      shareText += `${t('servings', language)}: ${generatedRecipe.servings}\n\n`;
      
      shareText += "INGREDIENTS:\n";
      generatedRecipe.ingredients?.forEach(ingredient => {
        shareText += `• ${ingredient.amount} ${ingredient.unit} ${ingredient.name}\n`;
      });
      
      shareText += "\nINSTRUCTIONS:\n";
      generatedRecipe.instructions?.forEach((instruction, index) => {
        shareText += `${index + 1}. ${instruction}\n`;
      });
      
      await Share.share({
        message: shareText,
        title: generatedRecipe.title,
      });
      
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error('Error sharing recipe:', error);
    }
  };
  
  const handleLanguageSelect = (langCode: string) => {
    setRecipeLanguage(langCode);
    setShowLanguageSelector(false);
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
  };
  
  const getLanguageDisplayName = (langCode: string) => {
    const lang = languages.find(l => l.id === langCode);
    return lang ? lang.nativeName : 'English';
  };
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidView}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {!generatedRecipe ? (
            <View style={styles.inputContainer}>
              <View style={styles.headerIconContainer}>
                <ChefHat size={normalize(40)} color={themeColors.primary} />
              </View>
              
              <Text style={[styles.title, { color: themeColors.text }]}>
                {t('createRecipe', language)}
              </Text>
              
              <Text style={[styles.description, { color: themeColors.subtext }]}>
                {t('enterDishName', language)}
              </Text>
              
              <View style={[styles.inputWrapper, { backgroundColor: themeColors.card, borderColor: themeColors.border }]}>
                <TextInput
                  style={[styles.input, { color: themeColors.text }]}
                  placeholder={t('enterDishNamePlaceholder', language)}
                  placeholderTextColor={themeColors.subtext}
                  value={dishName}
                  onChangeText={setDishName}
                  returnKeyType="done"
                />
              </View>
              
              <View style={styles.languageSelector}>
                <Text style={[styles.languageLabel, { color: themeColors.text }]}>
                  {t('recipeLanguage', language)}:
                </Text>
                
                <TouchableOpacity 
                  style={[styles.languageButton, { backgroundColor: themeColors.card }]}
                  onPress={() => setShowLanguageSelector(!showLanguageSelector)}
                >
                  <Text style={[styles.languageButtonText, { color: themeColors.primary }]}>
                    {getLanguageDisplayName(recipeLanguage)}
                  </Text>
                  <Languages size={normalize(16)} color={themeColors.primary} />
                </TouchableOpacity>
              </View>
              
              {showLanguageSelector && (
                <View style={[styles.languageList, { backgroundColor: themeColors.card, borderColor: themeColors.border }]}>
                  <ScrollView style={styles.languageScroll} nestedScrollEnabled={true}>
                    {languages.map((lang) => (
                      <TouchableOpacity
                        key={lang.id}
                        style={[
                          styles.languageItem,
                          recipeLanguage === lang.id && { backgroundColor: `${themeColors.primary}20` }
                        ]}
                        onPress={() => handleLanguageSelect(lang.id)}
                      >
                        <Text style={[styles.languageItemText, { color: themeColors.text }]}>
                          {lang.nativeName}
                        </Text>
                        {recipeLanguage === lang.id && (
                          <Check size={normalize(16)} color={themeColors.primary} />
                        )}
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              )}
              
              <TouchableOpacity
                style={[
                  styles.generateButton,
                  { backgroundColor: themeColors.primary },
                  isLoading && { opacity: 0.7 }
                ]}
                onPress={handleGenerateRecipe}
                disabled={isLoading || !dishName.trim()}
              >
                {isLoading ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.generateButtonText}>
                    {t('generateRecipe', language)}
                  </Text>
                )}
              </TouchableOpacity>
              
              {isLoading && (
                <View style={styles.loadingContainer}>
                  <Text style={[styles.loadingText, { color: themeColors.text }]}>
                    {t('creatingRecipe', language)}
                  </Text>
                  <Text style={[styles.loadingSubtext, { color: themeColors.subtext }]}>
                    {t('aiChefWorking', language)}
                  </Text>
                </View>
              )}
              
              {error && (
                <View style={[styles.errorContainer, { backgroundColor: `${themeColors.error}20` }]}>
                  <Text style={[styles.errorText, { color: themeColors.error }]}>
                    {error}
                  </Text>
                  <TouchableOpacity
                    style={[styles.tryAgainButton, { borderColor: themeColors.error }]}
                    onPress={clearError}
                  >
                    <Text style={[styles.tryAgainText, { color: themeColors.error }]}>
                      {t('tryAgain', language)}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ) : (
            <View style={styles.recipeContainer}>
              <View style={styles.recipeHeader}>
                <Text style={[styles.recipeTitle, { color: themeColors.text }]}>
                  {generatedRecipe.title}
                </Text>
                
                {generatedRecipe.description && (
                  <Text style={[styles.recipeDescription, { color: themeColors.subtext }]}>
                    {generatedRecipe.description}
                  </Text>
                )}
                
                <View style={styles.recipeMetaContainer}>
                  <View style={styles.recipeMeta}>
                    <Clock size={normalize(16)} color={themeColors.primary} />
                    <Text style={[styles.recipeMetaText, { color: themeColors.text }]}>
                      {generatedRecipe.cookingTimeMinutes} {t('mins', language)}
                    </Text>
                  </View>
                  
                  <View style={styles.recipeMeta}>
                    <Text style={[styles.recipeMetaText, { color: themeColors.text }]}>
                      {generatedRecipe.servings} {t('servings', language)}
                    </Text>
                  </View>
                </View>
              </View>
              
              <View style={styles.recipeContent}>
                <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
                  {t('ingredients', language)}
                </Text>
                
                <View style={styles.ingredientsList}>
                  {generatedRecipe.ingredients?.map((ingredient, index) => (
                <View key={index} style={styles.ingredientItem}>
                      <View style={[styles.ingredientDot, { backgroundColor: themeColors.primary }]} />
                      <Text style={[styles.ingredientText, { color: themeColors.text }]}>
                        {ingredient.amount} {ingredient.unit} {ingredient.name}
                      </Text>
                    </View>
                  ))}
                </View>
                
                <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
                  {t('instructions', language)}
                </Text>
                
                <View style={styles.instructionsList}>
                  {generatedRecipe.instructions?.map((instruction, index) => (
                    <View key={index} style={styles.instructionItem}>
                      <View style={[styles.instructionNumber, { backgroundColor: themeColors.primary }]}>
                        <Text style={styles.instructionNumberText}>{index + 1}</Text>
                      </View>
                      <Text style={[styles.instructionText, { color: themeColors.text }]}>
                        {instruction}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
              
              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={[styles.actionButton, { backgroundColor: themeColors.card }]}
                  onPress={handleShareRecipe}
                >
                  <Share2 size={normalize(20)} color={themeColors.primary} />
                  <Text style={[styles.actionButtonText, { color: themeColors.primary }]}>
                    {t('share', language)}
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[styles.actionButton, { backgroundColor: themeColors.primary }]}
                  onPress={handleSaveRecipe}
                >
                  <Text style={styles.saveButtonText}>
                    {t('save', language)}
                  </Text>
                </TouchableOpacity>
              </View>
              
              <TouchableOpacity
                style={[styles.newRecipeButton, { borderColor: themeColors.border }]}
                onPress={() => {
                  clearError();
                  setDishName('');
                }}
              >
                <ArrowLeft size={normalize(16)} color={themeColors.text} />
                <Text style={[styles.newRecipeButtonText, { color: themeColors.text }]}>
                  {t('newRecipe', language)}
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardAvoidView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: normalize(20),
  },
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: normalize(20),
  },
  headerIconContainer: {
    marginBottom: normalize(20),
  },
  title: {
    fontSize: responsiveFontSize(24),
    fontWeight: '700',
    marginBottom: normalize(12),
    textAlign: 'center',
  },
  description: {
    fontSize: responsiveFontSize(16),
    textAlign: 'center',
    marginBottom: normalize(30),
    paddingHorizontal: normalize(20),
  },
  inputWrapper: {
    width: '100%',
    borderRadius: normalize(12),
    borderWidth: 1,
    paddingHorizontal: normalize(16),
    paddingVertical: normalize(12),
    marginBottom: normalize(20),
  },
  input: {
    fontSize: responsiveFontSize(16),
    width: '100%',
  },
  languageSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: normalize(20),
  },
  languageLabel: {
    fontSize: responsiveFontSize(16),
    fontWeight: '500',
  },
  languageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: normalize(12),
    paddingVertical: normalize(8),
    borderRadius: normalize(8),
    gap: normalize(8),
  },
  languageButtonText: {
    fontSize: responsiveFontSize(14),
    fontWeight: '500',
  },
  languageList: {
    width: '100%',
    borderRadius: normalize(12),
    borderWidth: 1,
    maxHeight: normalize(200),
    marginBottom: normalize(20),
  },
  languageScroll: {
    width: '100%',
  },
  languageItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: normalize(16),
    paddingVertical: normalize(12),
  },
  languageItemText: {
    fontSize: responsiveFontSize(14),
  },
  generateButton: {
    width: '100%',
    paddingVertical: normalize(16),
    borderRadius: normalize(12),
    alignItems: 'center',
    justifyContent: 'center',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: responsiveFontSize(16),
    fontWeight: '600',
  },
  loadingContainer: {
    marginTop: normalize(30),
    alignItems: 'center',
  },
  loadingText: {
    fontSize: responsiveFontSize(18),
    fontWeight: '600',
    marginBottom: normalize(8),
  },
  loadingSubtext: {
    fontSize: responsiveFontSize(14),
    textAlign: 'center',
    paddingHorizontal: normalize(20),
  },
  errorContainer: {
    width: '100%',
    marginTop: normalize(20),
    padding: normalize(16),
    borderRadius: normalize(12),
    alignItems: 'center',
  },
  errorText: {
    fontSize: responsiveFontSize(14),
    marginBottom: normalize(12),
    textAlign: 'center',
  },
  tryAgainButton: {
    paddingHorizontal: normalize(16),
    paddingVertical: normalize(8),
    borderRadius: normalize(8),
    borderWidth: 1,
  },
  tryAgainText: {
    fontSize: responsiveFontSize(14),
    fontWeight: '500',
  },
  recipeContainer: {
    flex: 1,
  },
  recipeHeader: {
    marginBottom: normalize(24),
  },
  recipeTitle: {
    fontSize: responsiveFontSize(24),
    fontWeight: '700',
    marginBottom: normalize(8),
  },
  recipeDescription: {
    fontSize: responsiveFontSize(16),
    marginBottom: normalize(16),
    lineHeight: normalize(22),
  },
  recipeMetaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: normalize(16),
  },
  recipeMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: normalize(6),
  },
  recipeMetaText: {
    fontSize: responsiveFontSize(14),
  },
  recipeContent: {
    marginBottom: normalize(24),
  },
  sectionTitle: {
    fontSize: responsiveFontSize(18),
    fontWeight: '600',
    marginBottom: normalize(16),
  },
  ingredientsList: {
    marginBottom: normalize(24),
  },
  ingredientItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: normalize(12),
  },
  ingredientDot: {
    width: normalize(8),
    height: normalize(8),
    borderRadius: normalize(4),
    marginRight: normalize(12),
  },
  ingredientText: {
    fontSize: responsiveFontSize(16),
  },
  instructionsList: {
    marginBottom: normalize(24),
  },
  instructionItem: {
    flexDirection: 'row',
    marginBottom: normalize(16),
  },
  instructionNumber: {
    width: normalize(28),
    height: normalize(28),
    borderRadius: normalize(14),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: normalize(12),
    marginTop: normalize(2),
  },
  instructionNumberText: {
    color: '#FFFFFF',
    fontSize: responsiveFontSize(14),
    fontWeight: '600',
  },
  instructionText: {
    fontSize: responsiveFontSize(16),
    flex: 1,
    lineHeight: normalize(24),
  },
  actionButtons: {
    flexDirection: 'row',
    gap: normalize(12),
    marginBottom: normalize(24),
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: normalize(14),
    borderRadius: normalize(12),
    gap: normalize(8),
  },
  actionButtonText: {
    fontSize: responsiveFontSize(16),
    fontWeight: '600',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: responsiveFontSize(16),
    fontWeight: '600',
  },
  newRecipeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: normalize(14),
    borderRadius: normalize(12),
    borderWidth: 1,
    gap: normalize(8),
  },
  newRecipeButtonText: {
    fontSize: responsiveFontSize(16),
    fontWeight: '500',
  },
});