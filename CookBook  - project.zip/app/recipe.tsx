import React, { useState, useEffect } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Image, 
  TouchableOpacity, 
  Platform,
  Share as RNShare,
} from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useUserStore } from "@/store/user-store";
import { useLanguageStore } from "@/store/language-store";
import { Button } from "@/components/ui/Button";
import { IngredientItem } from "@/components/ui/IngredientItem";
import { InstructionStep } from "@/components/ui/InstructionStep";
import { Timer } from "@/components/ui/Timer";
import { NutritionInfo } from "@/components/ui/NutritionInfo";
import { RecipeList } from "@/components/ui/RecipeList";
import { Recipe } from "@/types/recipe";
import { 
  Clock, 
  ChefHat, 
  Users, 
  Heart, 
  Share, 
  Play, 
  Plus, 
  Minus,
  ShoppingCart,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { t } from "@/constants/translations";
import { normalize } from "@/constants/layout";

export default function RecipeScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { getRecipeById, recipes } = useRecipeStore();
  const { 
    addToFavorites, 
    removeFromFavorites, 
    isFavorite, 
    addToHistory,
    addToShoppingList,
  } = useUserStore();
  
  const recipe = getRecipeById(id as string);
  
  const [activeTab, setActiveTab] = useState<'ingredients' | 'instructions'>('ingredients');
  const [servings, setServings] = useState(recipe?.servings || 1);
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [timer, setTimer] = useState<{ seconds: number } | null>(null);
  
  useEffect(() => {
    if (recipe) {
      addToHistory(recipe.id);
    }
  }, [recipe?.id]);

  if (!recipe) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
        <Text style={[styles.errorText, { color: themeColors.text }]}>
          {t('recipeNotFound', language)}
        </Text>
      </SafeAreaView>
    );
  }

  const handleFavoriteToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    if (isFavorite(recipe.id)) {
      removeFromFavorites(recipe.id);
    } else {
      addToFavorites(recipe.id);
    }
  };

  const handleShare = async () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    try {
      if (Platform.OS === 'web') {
        alert(t('sharingNotAvailableOnWeb', language));
        return;
      }
      
      await RNShare.share({
        title: recipe.title,
        message: `${t('checkOutThisRecipe', language)}: ${recipe.title}!`,
      });
    } catch (error) {
      console.error("Error sharing recipe:", error);
    }
  };

  const handleServingsChange = (change: number) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    const newServings = servings + change;
    if (newServings >= 1) {
      setServings(newServings);
    }
  };

  const handleTabChange = (tab: 'ingredients' | 'instructions') => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setActiveTab(tab);
  };

  const handleAddToShoppingList = (ingredient: any) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    addToShoppingList({
      name: ingredient.name,
      amount: ingredient.amount,
      unit: ingredient.unit,
      recipeId: recipe.id,
      recipeName: recipe.title,
      checked: false,
    });
  };

  const handleStartTimer = (seconds: number) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setTimer({ seconds });
  };

  const handleTimerComplete = () => {
    setTimer(null);
  };

  const isIngredientInShoppingList = (ingredientName: string) => {
    const shoppingList = useUserStore.getState().shoppingList;
    return shoppingList.some(item => 
      item.name.toLowerCase() === ingredientName.toLowerCase() && 
      item.recipeId === recipe.id
    ) || false;
  };

  // Safely get related recipes
  const getRelatedRecipes = () => {
    if (recipe.relatedRecipes && Array.isArray(recipe.relatedRecipes)) {
      return recipe.relatedRecipes
        .map(id => getRecipeById(id))
        .filter(Boolean) as Recipe[];
    }
    
    // Fallback to similar recipes by cuisine or meal type
    if (recipes && Array.isArray(recipes)) {
      return recipes.filter(r => 
        r.id !== recipe.id && 
        (r.cuisine === recipe.cuisine || 
         r.mealType.some(type => recipe.mealType.includes(type)))
      ).slice(0, 5);
    }
    
    return [];
  };

  const relatedRecipes = getRelatedRecipes();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack.Screen 
        options={{
          headerTitle: recipe.title,
          headerRight: () => (
            <View style={styles.headerButtons}>
              <TouchableOpacity 
                style={styles.headerButton} 
                onPress={handleFavoriteToggle}
              >
                <Heart 
                  size={normalize(24)} 
                  color={themeColors.primary} 
                  fill={isFavorite(recipe.id) ? themeColors.primary : "transparent"} 
                />
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.headerButton} 
                onPress={handleShare}
              >
                <Share size={normalize(24)} color={themeColors.text} />
              </TouchableOpacity>
            </View>
          ),
        }} 
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.imageContainer}>
          <Image source={{ uri: recipe.imageUrl }} style={styles.image} />
          {recipe.videoUrl && (
            <TouchableOpacity style={styles.playButton}>
              <Play size={normalize(24)} color="white" fill="white" />
            </TouchableOpacity>
          )}
        </View>
        
        <View style={styles.content}>
          <Text style={[styles.title, { color: themeColors.text }]}>{recipe.title}</Text>
          
          <View style={styles.metaContainer}>
            <View style={styles.metaItem}>
              <Clock size={normalize(16)} color={themeColors.subtext} />
              <Text style={[styles.metaText, { color: themeColors.subtext }]}>
                {recipe.totalTime} min
              </Text>
            </View>
            <View style={styles.metaItem}>
              <ChefHat size={normalize(16)} color={themeColors.subtext} />
              <Text style={[styles.metaText, { color: themeColors.subtext }]}>
                {recipe.difficulty}
              </Text>
            </View>
          </View>
          
          <Text style={[styles.description, { color: themeColors.text }]}>
            {recipe.description}
          </Text>
          
          <View style={styles.tagsContainer}>
            {recipe.dietaryTags && recipe.dietaryTags.map((tag, index) => (
              <View 
                key={index} 
                style={[
                  styles.tag, 
                  { 
                    backgroundColor: themeColors.card,
                    borderColor: themeColors.border,
                  }
                ]}
              >
                <Text style={[styles.tagText, { color: themeColors.text }]}>
                  {tag}
                </Text>
              </View>
            ))}
          </View>
          
          {timer && (
            <Timer 
              seconds={timer.seconds} 
              onComplete={handleTimerComplete}
              onClose={() => setTimer(null)}
            />
          )}
          
          <View style={styles.tabsContainer}>
            <TouchableOpacity 
              style={[
                styles.tab, 
                activeTab === 'ingredients' && [
                  styles.activeTab,
                  { borderBottomColor: themeColors.primary }
                ]
              ]}
              onPress={() => handleTabChange('ingredients')}
            >
              <Text 
                style={[
                  styles.tabText, 
                  { 
                    color: activeTab === 'ingredients' 
                      ? themeColors.primary 
                      : themeColors.subtext 
                  }
                ]}
              >
                {t('ingredients', language)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[
                styles.tab, 
                activeTab === 'instructions' && [
                  styles.activeTab,
                  { borderBottomColor: themeColors.primary }
                ]
              ]}
              onPress={() => handleTabChange('instructions')}
            >
              <Text 
                style={[
                  styles.tabText, 
                  { 
                    color: activeTab === 'instructions' 
                      ? themeColors.primary 
                      : themeColors.subtext 
                  }
                ]}
              >
                {t('instructions', language)}
              </Text>
            </TouchableOpacity>
          </View>
          
          {activeTab === 'ingredients' && (
            <View style={styles.ingredientsContainer}>
              <View style={styles.servingsContainer}>
                <View style={styles.servingsLeft}>
                  <Users size={normalize(20)} color={themeColors.text} />
                  <Text style={[styles.servingsText, { color: themeColors.text }]}>
                    {t('servings', language)}
                  </Text>
                </View>
                <View style={styles.servingsControls}>
                  <TouchableOpacity 
                    style={[
                      styles.servingsButton, 
                      { 
                        backgroundColor: themeColors.card,
                        borderColor: themeColors.border,
                      }
                    ]}
                    onPress={() => handleServingsChange(-1)}
                    disabled={servings <= 1}
                  >
                    <Minus 
                      size={normalize(16)} 
                      color={servings <= 1 ? themeColors.inactive : themeColors.text} 
                    />
                  </TouchableOpacity>
                  <Text style={[styles.servingsValue, { color: themeColors.text }]}>
                    {servings}
                  </Text>
                  <TouchableOpacity 
                    style={[
                      styles.servingsButton, 
                      { 
                        backgroundColor: themeColors.card,
                        borderColor: themeColors.border,
                      }
                    ]}
                    onPress={() => handleServingsChange(1)}
                  >
                    <Plus size={normalize(16)} color={themeColors.text} />
                  </TouchableOpacity>
                </View>
              </View>
              
              <View style={styles.ingredientsList}>
                {recipe.ingredients && recipe.ingredients.map((ingredient, index) => (
                  <IngredientItem 
                    key={index}
                    ingredient={ingredient}
                    servings={servings}
                    originalServings={recipe.servings}
                    isInShoppingList={isIngredientInShoppingList(ingredient.name)}
                    onAddToShoppingList={() => handleAddToShoppingList(ingredient)}
                  />
                ))}
              </View>
              
              <Button
                title={t('addAllToShoppingList', language)}
                onPress={() => {
                  if (recipe.ingredients) {
                    recipe.ingredients.forEach(ingredient => {
                      if (!isIngredientInShoppingList(ingredient.name)) {
                        handleAddToShoppingList(ingredient);
                      }
                    });
                    if (Platform.OS !== 'web') {
                      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                    }
                  }
                }}
                icon={<ShoppingCart size={normalize(16)} color="white" />}
                fullWidth
                style={styles.addAllButton}
              />
            </View>
          )}
          
          {activeTab === 'instructions' && (
            <View style={styles.instructionsContainer}>
              {recipe.instructions && recipe.instructions.map((instruction, index) => (
                <InstructionStep 
                  key={index}
                  instruction={instruction}
                  isActive={activeStep === instruction.step}
                  onTimerStart={handleStartTimer}
                />
              ))}
            </View>
          )}
          
          {recipe.nutritionInfo && <NutritionInfo nutritionInfo={recipe.nutritionInfo} />}
          
          {relatedRecipes && relatedRecipes.length > 0 && (
            <View style={styles.relatedContainer}>
              <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
                {t('youMightAlsoLike', language)}
              </Text>
              <RecipeList 
                recipes={relatedRecipes}
                title=""
                horizontal={true}
                variant="vertical"
                showViewAll={false}
                showsHorizontalScrollIndicator={false}
              />
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  errorText: {
    fontSize: 18,
    textAlign: "center",
    marginTop: 24,
  },
  headerButtons: {
    flexDirection: "row",
    gap: 16,
    marginRight: 8,
  },
  headerButton: {
    padding: 4,
  },
  imageContainer: {
    position: "relative",
    height: 250,
  },
  image: {
    width: "100%",
    height: "100%",
  },
  playButton: {
    position: "absolute",
    top: "50%",
    left: "50%",
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    marginLeft: -30,
    marginTop: -30,
  },
  content: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 12,
  },
  metaContainer: {
    flexDirection: "row",
    marginBottom: 16,
    gap: 16,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 14,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 16,
  },
  tagsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 24,
  },
  tag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
  },
  tagText: {
    fontSize: 12,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  tabsContainer: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
    marginBottom: 16,
  },
  tab: {
    paddingVertical: 12,
    marginRight: 24,
  },
  activeTab: {
    borderBottomWidth: 2,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "600",
  },
  ingredientsContainer: {
    marginBottom: 24,
  },
  servingsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  servingsLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  servingsText: {
    fontSize: 16,
    fontWeight: "600",
  },
  servingsControls: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  servingsButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
  },
  servingsValue: {
    fontSize: 16,
    fontWeight: "600",
    minWidth: 24,
    textAlign: "center",
  },
  ingredientsList: {
    marginBottom: 16,
  },
  addAllButton: {
    marginTop: 8,
  },
  instructionsContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 16,
  },
  relatedContainer: {
    marginBottom: 24,
  },
});