import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useFonts } from "expo-font";
import { Stack, SplashScreen } from "expo-router";
import { useEffect } from "react";
import { Platform, Dimensions } from "react-native";
import { ErrorBoundary } from "./error-boundary";
import { StatusBar } from "expo-status-bar";
import { useThemeStore } from "@/store/theme-store";
import { useLanguageStore } from "@/store/language-store";
import { t } from "@/constants/translations";
import layout from "@/constants/layout";

export const unstable_settings = {
  initialRouteName: "(tabs)",
};

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
    ...FontAwesome.font,
  });

  // Listen for dimension changes to update responsive layout
  useEffect(() => {
    const subscription = Dimensions.addEventListener(
      'change',
      ({ window }) => {
        // This will trigger a re-render when dimensions change
        // The layout utility will handle the updated dimensions
      }
    );
    
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    if (error) {
      console.error(error);
      throw error;
    }
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <ErrorBoundary>
      <RootLayoutNav />
    </ErrorBoundary>
  );
}

function RootLayoutNav() {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const { language } = useLanguageStore();
  
  return (
    <>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen 
          name="recipe" 
          options={{ 
            headerTitle: t('recipe', language) || "Recipe Details",
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
        <Stack.Screen 
          name="search" 
          options={{ 
            headerTitle: t('search', language),
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
        <Stack.Screen 
          name="filter" 
          options={{ 
            headerTitle: t('filter', language) || "Filter Recipes",
            headerBackTitle: t('back', language) || "Back",
            presentation: "modal",
          }} 
        />
        <Stack.Screen 
          name="ai-recipe" 
          options={{ 
            headerTitle: t('aiRecipeGenerator', language),
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
        <Stack.Screen 
          name="ingredients-search" 
          options={{ 
            headerTitle: t('cookWithIngredients', language),
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
        <Stack.Screen 
          name="meal-plan-edit" 
          options={{ 
            headerTitle: t('mealPlans', language),
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
        <Stack.Screen 
          name="settings" 
          options={{ 
            headerTitle: t('settings', language),
            headerBackTitle: t('back', language) || "Back",
            presentation: "card",
          }} 
        />
      </Stack>
    </>
  );
}