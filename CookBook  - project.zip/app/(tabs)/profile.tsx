import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { colors } from '@/constants/colors';
import { useThemeStore } from '@/store/theme-store';
import { useLanguageStore } from '@/store/language-store';
import { useUserStore } from '@/store/user-store';
import { t } from '@/constants/translations';
import {
  Moon,
  Sun,
  Globe,
  Bell,
  ChevronRight,
  Heart,
  Clock,
  BookOpen,
  Calendar,
  ShoppingCart,
  Settings,
  HelpCircle,
  Info,
  LogOut,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import layout, { normalize, responsiveFontSize } from '@/constants/layout';

export default function ProfileScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { setTheme } = useThemeStore();
  const { language } = useLanguageStore();
  
  const { preferences, updatePreferences } = useUserStore();
  
  const handleThemeToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    const newTheme = activeTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    updatePreferences({ theme: newTheme });
  };
  
  const handleNotificationsToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    updatePreferences({ 
      notificationsEnabled: !preferences.notificationsEnabled 
    });
  };
  
  const handleMeasurementSystemToggle = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    updatePreferences({ 
      measurementSystem: preferences.measurementSystem === 'metric' ? 'imperial' : 'metric' 
    });
  };
  
  const navigateToSettings = () => {
    router.push('/settings');
  };
  
  const navigateToLanguageSettings = () => {
    // This would navigate to language settings
    console.log('Navigate to language settings');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: themeColors.text }]}>
            {t('settings', language)}
          </Text>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('account', language)}
          </Text>
          
          <View style={[styles.card, { backgroundColor: themeColors.card }]}>
            <TouchableOpacity 
              style={styles.settingRow}
              onPress={() => router.push('/cookbook')}
            >
              <View style={styles.settingIconContainer}>
                <BookOpen size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('cookbook', language)}
              </Text>
              <ChevronRight size={normalize(18)} color={themeColors.subtext} />
            </TouchableOpacity>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <TouchableOpacity 
              style={styles.settingRow}
              onPress={() => router.push('/shopping')}
            >
              <View style={styles.settingIconContainer}>
                <ShoppingCart size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('shoppingList', language)}
              </Text>
              <ChevronRight size={normalize(18)} color={themeColors.subtext} />
            </TouchableOpacity>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <TouchableOpacity 
              style={styles.settingRow}
              onPress={() => router.push('/meal-plan-edit')}
            >
              <View style={styles.settingIconContainer}>
                <Calendar size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('mealPlans', language)}
              </Text>
              <ChevronRight size={normalize(18)} color={themeColors.subtext} />
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('preferences', language)}
          </Text>
          
          <View style={[styles.card, { backgroundColor: themeColors.card }]}>
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                {activeTheme === 'dark' ? (
                  <Moon size={normalize(20)} color={themeColors.primary} />
                ) : (
                  <Sun size={normalize(20)} color={themeColors.primary} />
                )}
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('darkMode', language)}
              </Text>
              <Switch
                value={activeTheme === 'dark'}
                onValueChange={handleThemeToggle}
                trackColor={{ 
                  false: themeColors.inactive, 
                  true: themeColors.primary 
                }}
                thumbColor={Platform.OS === 'ios' ? undefined : 'white'}
                ios_backgroundColor={themeColors.inactive}
                style={styles.switch}
              />
            </View>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <TouchableOpacity 
              style={styles.settingRow}
              onPress={navigateToLanguageSettings}
            >
              <View style={styles.settingIconContainer}>
                <Globe size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('language', language)}
              </Text>
              <View style={styles.valueContainer}>
                <Text style={[styles.valueText, { color: themeColors.subtext }]}>
                  {language.toUpperCase()}
                </Text>
                <ChevronRight size={normalize(18)} color={themeColors.subtext} />
              </View>
            </TouchableOpacity>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <Bell size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('notifications', language)}
              </Text>
              <Switch
                value={preferences.notificationsEnabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ 
                  false: themeColors.inactive, 
                  true: themeColors.primary 
                }}
                thumbColor={Platform.OS === 'ios' ? undefined : 'white'}
                ios_backgroundColor={themeColors.inactive}
                style={styles.switch}
              />
            </View>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <Settings size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('measurementSystem', language)}
              </Text>
              <View style={styles.valueContainer}>
                <Text style={[styles.valueText, { color: themeColors.subtext }]}>
                  {preferences.measurementSystem === 'metric' ? 'Metric' : 'Imperial'}
                </Text>
                <Switch
                  value={preferences.measurementSystem === 'metric'}
                  onValueChange={handleMeasurementSystemToggle}
                  trackColor={{ 
                    false: themeColors.inactive, 
                    true: themeColors.primary 
                  }}
                  thumbColor={Platform.OS === 'ios' ? undefined : 'white'}
                  ios_backgroundColor={themeColors.inactive}
                  style={styles.switch}
                />
              </View>
            </View>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('about', language)}
          </Text>
          
          <View style={[styles.card, { backgroundColor: themeColors.card }]}>
            <TouchableOpacity style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <HelpCircle size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('help', language)}
              </Text>
              <ChevronRight size={normalize(18)} color={themeColors.subtext} />
            </TouchableOpacity>
            
            <View style={[styles.divider, { backgroundColor: themeColors.border }]} />
            
            <TouchableOpacity style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <Info size={normalize(20)} color={themeColors.primary} />
              </View>
              <Text style={[styles.settingText, { color: themeColors.text }]}>
                {t('about', language)}
              </Text>
              <ChevronRight size={normalize(18)} color={themeColors.subtext} />
            </TouchableOpacity>
          </View>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.logoutButton, 
            { backgroundColor: themeColors.card }
          ]}
        >
          <LogOut size={normalize(20)} color={themeColors.error} />
          <Text style={[styles.logoutText, { color: themeColors.error }]}>
            {t('logout', language)}
          </Text>
        </TouchableOpacity>
        
        <Text style={[styles.versionText, { color: themeColors.subtext }]}>
          Version 1.0.0
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: normalize(16),
    paddingVertical: normalize(16),
  },
  title: {
    fontSize: responsiveFontSize(24),
    fontWeight: '700',
  },
  section: {
    marginBottom: normalize(24),
  },
  sectionTitle: {
    fontSize: responsiveFontSize(18),
    fontWeight: '600',
    marginBottom: normalize(12),
    paddingHorizontal: normalize(16),
  },
  card: {
    marginHorizontal: normalize(16),
    borderRadius: layout.borderRadius.large,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: normalize(14),
    paddingHorizontal: normalize(16),
  },
  settingIconContainer: {
    width: normalize(32),
    height: normalize(32),
    borderRadius: normalize(16),
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: normalize(12),
  },
  settingText: {
    fontSize: responsiveFontSize(16),
    flex: 1,
  },
  valueContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  valueText: {
    fontSize: responsiveFontSize(14),
    marginRight: normalize(8),
  },
  switch: {
    transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
  },
  divider: {
    height: 1,
    marginHorizontal: normalize(16),
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: normalize(16),
    paddingVertical: normalize(14),
    borderRadius: layout.borderRadius.large,
    marginBottom: normalize(16),
  },
  logoutText: {
    fontSize: responsiveFontSize(16),
    fontWeight: '600',
    marginLeft: normalize(8),
  },
  versionText: {
    textAlign: 'center',
    fontSize: responsiveFontSize(12),
    marginBottom: normalize(32),
  },
});