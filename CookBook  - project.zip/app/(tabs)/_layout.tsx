import React from "react";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useLanguageStore } from "@/store/language-store";
import { t } from "@/constants/translations";
import { Home, Search, BookOpen, ShoppingCart, Settings } from "lucide-react-native";
import layout, { normalize, responsiveFontSize } from "@/constants/layout";

export default function TabLayout() {
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: themeColors.primary,
        tabBarInactiveTintColor: themeColors.inactive,
        tabBarStyle: {
          backgroundColor: themeColors.background,
          borderTopColor: themeColors.border,
          height: normalize(Platform.OS === 'ios' ? 88 : 60),
          paddingTop: normalize(8),
          paddingBottom: normalize(Platform.OS === 'ios' ? 28 : 8),
        },
        headerStyle: {
          backgroundColor: themeColors.background,
        },
        headerTintColor: themeColors.text,
        tabBarLabelStyle: {
          fontSize: responsiveFontSize(12),
          marginTop: normalize(2),
        },
        tabBarIconStyle: {
          marginBottom: normalize(2),
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t('home', language),
          tabBarIcon: ({ color, size }) => <Home size={normalize(size)} color={color} />,
        }}
      />
      <Tabs.Screen
        name="discover"
        options={{
          title: t('discover', language),
          tabBarIcon: ({ color, size }) => <Search size={normalize(size)} color={color} />,
        }}
      />
      <Tabs.Screen
        name="cookbook"
        options={{
          title: t('cookbook', language),
          tabBarIcon: ({ color, size }) => <BookOpen size={normalize(size)} color={color} />,
        }}
      />
      <Tabs.Screen
        name="shopping"
        options={{
          title: t('shopping', language),
          tabBarIcon: ({ color, size }) => <ShoppingCart size={normalize(size)} color={color} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t('settings', language),
          tabBarIcon: ({ color, size }) => <Settings size={normalize(size)} color={color} />,
        }}
      />
    </Tabs>
  );
}