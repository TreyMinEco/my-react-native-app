import React, { useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useUserStore } from "@/store/user-store";
import { RecipeCard } from "@/components/ui/RecipeCard";
import { SearchBar } from "@/components/ui/SearchBar";
import { Heart, History, Plus, BookOpen } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { Recipe } from "@/types/recipe";

type TabType = 'favorites' | 'history' | 'my-recipes';

export default function CookbookScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const [activeTab, setActiveTab] = useState<TabType>('favorites');
  const [searchQuery, setSearchQuery] = useState("");
  
  const { recipes, getRecipeById } = useRecipeStore();
  const { favorites, history, createdRecipes } = useUserStore();

  const favoriteRecipes = favorites.map(id => getRecipeById(id)).filter(Boolean) as Recipe[] || [];
  const historyRecipes = history
    .map(item => getRecipeById(item.recipeId))
    .filter(Boolean) as Recipe[] || [];
  const myRecipes = createdRecipes
    .map(id => getRecipeById(id))
    .filter(Boolean) as Recipe[] || [];

  const filteredRecipes = () => {
    let recipeList: Recipe[] = [];
    
    switch (activeTab) {
      case 'favorites':
        recipeList = favoriteRecipes;
        break;
      case 'history':
        recipeList = historyRecipes;
        break;
      case 'my-recipes':
        recipeList = myRecipes;
        break;
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return recipeList.filter(recipe => 
        recipe.title.toLowerCase().includes(query) || 
        recipe.description.toLowerCase().includes(query)
      );
    }
    
    return recipeList;
  };

  const handleTabPress = (tab: TabType) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setActiveTab(tab);
  };

  const handleAddRecipe = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    // Navigate to add recipe screen
    router.push("/ai-recipe");
  };

  const renderEmptyState = () => {
    let message = "";
    let action = "";
    
    switch (activeTab) {
      case 'favorites':
        message = "You haven't saved any favorites yet";
        action = "Browse recipes and tap the heart icon to save them here";
        break;
      case 'history':
        message = "No recently viewed recipes";
        action = "Browse recipes to see your history here";
        break;
      case 'my-recipes':
        message = "You haven't created any recipes yet";
        action = "Tap the + button to add your own recipe";
        break;
    }
    
    return (
      <View style={styles.emptyContainer}>
        <Text style={[styles.emptyTitle, { color: themeColors.text }]}>
          {message}
        </Text>
        <Text style={[styles.emptyText, { color: themeColors.subtext }]}>
          {action}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <View style={styles.header}>
        <Text style={[styles.title, { color: themeColors.text }]}>Cookbook</Text>
        {activeTab === 'my-recipes' && (
          <TouchableOpacity 
            style={[styles.addButton, { backgroundColor: themeColors.primary }]}
            onPress={handleAddRecipe}
          >
            <Plus size={20} color="white" />
          </TouchableOpacity>
        )}
      </View>
      
      <View style={[styles.tabs, { borderBottomColor: themeColors.border }]}>
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'favorites' && [
              styles.activeTab,
              { borderBottomColor: themeColors.primary }
            ]
          ]}
          onPress={() => handleTabPress('favorites')}
        >
          <Heart 
            size={18} 
            color={activeTab === 'favorites' ? themeColors.primary : themeColors.subtext} 
          />
          <Text 
            style={[
              styles.tabText, 
              { 
                color: activeTab === 'favorites' 
                  ? themeColors.primary 
                  : themeColors.subtext 
              }
            ]}
          >
            Favorites
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'history' && [
              styles.activeTab,
              { borderBottomColor: themeColors.primary }
            ]
          ]}
          onPress={() => handleTabPress('history')}
        >
          <History 
            size={18} 
            color={activeTab === 'history' ? themeColors.primary : themeColors.subtext} 
          />
          <Text 
            style={[
              styles.tabText, 
              { 
                color: activeTab === 'history' 
                  ? themeColors.primary 
                  : themeColors.subtext 
              }
            ]}
          >
            History
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'my-recipes' && [
              styles.activeTab,
              { borderBottomColor: themeColors.primary }
            ]
          ]}
          onPress={() => handleTabPress('my-recipes')}
        >
          <BookOpen 
            size={18} 
            color={activeTab === 'my-recipes' ? themeColors.primary : themeColors.subtext} 
          />
          <Text 
            style={[
              styles.tabText, 
              { 
                color: activeTab === 'my-recipes' 
                  ? themeColors.primary 
                  : themeColors.subtext 
              }
            ]}
          >
            My Recipes
          </Text>
        </TouchableOpacity>
      </View>
      
      <SearchBar 
        placeholder={`Search ${activeTab === 'favorites' ? 'favorites' : activeTab === 'history' ? 'history' : 'my recipes'}...`}
        value={searchQuery}
        onChangeText={setSearchQuery}
        style={styles.searchContainer}
      />
      
      <FlatList
        data={filteredRecipes()}
        renderItem={({ item }) => (
          <View style={styles.recipeItem}>
            <RecipeCard recipe={item} variant="horizontal" />
          </View>
        )}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={renderEmptyState}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 8,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  tabs: {
    flexDirection: "row",
    paddingHorizontal: 16,
    borderBottomWidth: 1,
  },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    marginRight: 24,
    gap: 6,
  },
  activeTab: {
    borderBottomWidth: 2,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "500",
  },
  searchContainer: {
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 0,
  },
  listContent: {
    padding: 16,
  },
  recipeItem: {
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 48,
    paddingHorizontal: 24,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
    textAlign: "center",
  },
  emptyText: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
  },
});