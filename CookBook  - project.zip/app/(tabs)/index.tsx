import React from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Image,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { useLanguageStore } from "@/store/language-store";
import { t } from "@/constants/translations";
import { RecipeList } from "@/components/ui/RecipeList";
import { SearchBar } from "@/components/ui/SearchBar";
import { CategoryPill } from "@/components/ui/CategoryPill";
import { mealTypes } from "@/mocks/categories";
import { ChefHat, Wand2 } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import layout, { normalize, responsiveFontSize } from "@/constants/layout";

export default function HomeScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  const { language } = useLanguageStore();
  
  const { 
    featuredRecipes, 
    popularRecipes, 
    recentRecipes,
    setSearchQuery,
  } = useRecipeStore();

  const handleSearch = (text: string) => {
    setSearchQuery(text);
    router.push("/search");
  };

  const handleCategoryPress = (category: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push({
      pathname: "/search",
      params: { category },
    });
  };

  const handleAIRecipePress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    router.push("/ai-recipe");
  };

  const handleIngredientSearchPress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push("/ingredients-search");
  };

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "morning";
    if (hour < 18) return "afternoon";
    return "evening";
  };

  const getGreeting = () => {
    const timeOfDay = getTimeOfDay();
    if (timeOfDay === "morning") return t('goodMorning', language);
    if (timeOfDay === "afternoon") return t('goodAfternoon', language);
    return t('goodEvening', language);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: themeColors.text }]}>
              {getGreeting()},
            </Text>
            <Text style={[styles.name, { color: themeColors.text }]}>
              {t('home', language)}
            </Text>
          </View>
        </View>
        
        <SearchBar 
          placeholder={t('searchForRecipes', language)}
          value=""
          onChangeText={handleSearch}
          onVoiceSearch={() => console.log("Voice search")}
          onCameraSearch={() => console.log("Camera search")}
        />
        
        <View style={styles.categoriesContainer}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            {t('categories', language)}
          </Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScroll}
          >
            {mealTypes.slice(0, 8).map((category) => (
              <CategoryPill 
                key={category.id}
                label={category.name}
                onPress={() => handleCategoryPress(category.id)}
              />
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.featuresContainer}>
          <TouchableOpacity 
            style={[styles.featureCard, { backgroundColor: themeColors.card }]}
            onPress={handleAIRecipePress}
            activeOpacity={0.8}
          >
            <View style={[styles.featureIconContainer, { backgroundColor: 'rgba(255, 112, 67, 0.1)' }]}>
              <Wand2 size={normalize(24)} color={themeColors.primary} />
            </View>
            <Text style={[styles.featureTitle, { color: themeColors.text }]}>
              {t('aiRecipeGenerator', language)}
            </Text>
            <Text style={[styles.featureDescription, { color: themeColors.subtext }]}>
              {t('createCustomRecipes', language)}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.featureCard, { backgroundColor: themeColors.card }]}
            onPress={handleIngredientSearchPress}
            activeOpacity={0.8}
          >
            <View style={[styles.featureIconContainer, { backgroundColor: 'rgba(76, 175, 80, 0.1)' }]}>
              <ChefHat size={normalize(24)} color={colors.light.secondary} />
            </View>
            <Text style={[styles.featureTitle, { color: themeColors.text }]}>
              {t('cookWithIngredients', language)}
            </Text>
            <Text style={[styles.featureDescription, { color: themeColors.subtext }]}>
              {t('findRecipesWithWhatYouHave', language)}
            </Text>
          </TouchableOpacity>
        </View>
        
        {featuredRecipes.length > 0 && (
          <View style={styles.featuredContainer}>
            <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
              {t('featuredRecipes', language)}
            </Text>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.featuredScroll}
              decelerationRate="fast"
              snapToInterval={normalize(320) + normalize(16)}
              snapToAlignment="start"
            >
              {featuredRecipes.map((recipe) => (
                <View key={recipe.id} style={styles.featuredItem}>
                  <TouchableOpacity 
                    activeOpacity={0.9}
                    onPress={() => router.push(`/recipe?id=${recipe.id}`)}
                    style={styles.featuredCard}
                  >
                    <Image 
                      source={{ uri: recipe.imageUrl }} 
                      style={styles.featuredImage}
                    />
                    <View style={styles.featuredGradient} />
                    <View style={styles.featuredContent}>
                      <View style={styles.featuredMeta}>
                        <View style={styles.featuredTag}>
                          <Text style={styles.featuredTagText}>{recipe.cuisine}</Text>
                        </View>
                      </View>
                      <Text style={styles.featuredTitle}>{recipe.title}</Text>
                      <Text style={styles.featuredDescription} numberOfLines={2}>
                        {recipe.description}
                      </Text>
                    </View>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          </View>
        )}
        
        <RecipeList 
          title={t('popularRecipes', language)}
          recipes={popularRecipes}
          horizontal={true}
          variant="vertical"
        />
        
        <RecipeList 
          title={t('recentlyAdded', language)}
          recipes={recentRecipes}
          horizontal={true}
          variant="vertical"
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: normalize(24),
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: normalize(16),
    paddingTop: normalize(8),
    paddingBottom: normalize(16),
  },
  greeting: {
    fontSize: responsiveFontSize(16),
  },
  name: {
    fontSize: responsiveFontSize(24),
    fontWeight: "700",
  },
  avatar: {
    width: normalize(48),
    height: normalize(48),
    borderRadius: normalize(24),
  },
  categoriesContainer: {
    marginBottom: normalize(24),
  },
  sectionTitle: {
    fontSize: responsiveFontSize(20),
    fontWeight: "700",
    marginBottom: normalize(16),
    paddingHorizontal: normalize(16),
  },
  categoriesScroll: {
    paddingHorizontal: normalize(16),
    gap: normalize(8),
  },
  featuresContainer: {
    flexDirection: "row",
    paddingHorizontal: normalize(16),
    gap: normalize(16),
    marginBottom: normalize(24),
  },
  featureCard: {
    flex: 1,
    borderRadius: layout.borderRadius.xl,
    padding: normalize(16),
    ...Platform.select({
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  featureIconContainer: {
    width: normalize(48),
    height: normalize(48),
    borderRadius: normalize(24),
    justifyContent: "center",
    alignItems: "center",
    marginBottom: normalize(12),
  },
  featureTitle: {
    fontSize: responsiveFontSize(16),
    fontWeight: "600",
    marginBottom: normalize(4),
  },
  featureDescription: {
    fontSize: responsiveFontSize(12),
    lineHeight: normalize(16),
  },
  featuredContainer: {
    marginBottom: normalize(24),
  },
  featuredScroll: {
    paddingLeft: normalize(16),
    paddingRight: normalize(8),
  },
  featuredItem: {
    width: normalize(320),
    marginRight: normalize(16),
  },
  featuredCard: {
    height: normalize(200),
    borderRadius: layout.borderRadius.xl,
    overflow: "hidden",
  },
  featuredImage: {
    width: "100%",
    height: "100%",
  },
  featuredGradient: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: "70%",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    backgroundImage: "linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent)",
  },
  featuredContent: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: normalize(16),
  },
  featuredMeta: {
    flexDirection: "row",
    marginBottom: normalize(8),
  },
  featuredTag: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    paddingHorizontal: normalize(8),
    paddingVertical: normalize(4),
    borderRadius: normalize(4),
  },
  featuredTagText: {
    color: "white",
    fontSize: responsiveFontSize(12),
    fontWeight: "500",
    textTransform: "capitalize",
  },
  featuredTitle: {
    color: "white",
    fontSize: responsiveFontSize(18),
    fontWeight: "700",
    marginBottom: normalize(4),
  },
  featuredDescription: {
    color: "rgba(255, 255, 255, 0.8)",
    fontSize: responsiveFontSize(12),
    lineHeight: normalize(16),
  },
});