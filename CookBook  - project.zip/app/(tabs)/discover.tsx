import React, { useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useRecipeStore } from "@/store/recipe-store";
import { SearchBar } from "@/components/ui/SearchBar";
import { CategoryPill } from "@/components/ui/CategoryPill";
import { RecipeCard } from "@/components/ui/RecipeCard";
import { cuisines, dietaryTags, mealTypes } from "@/mocks/categories";
import { Filter } from "lucide-react-native";
import * as Haptics from "expo-haptics";

export default function DiscoverScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const { recipes, setSearchQuery: setGlobalSearchQuery } = useRecipeStore();

  const handleSearch = () => {
    setGlobalSearchQuery(searchQuery);
    router.push("/search");
  };

  const handleCategoryPress = (category: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (selectedCategory === category) {
      setSelectedCategory(null);
    } else {
      setSelectedCategory(category);
      router.push({
        pathname: "/search",
        params: { category },
      });
    }
  };

  const handleFilterPress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push("/filter");
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <View style={styles.header}>
        <Text style={[styles.title, { color: themeColors.text }]}>Discover</Text>
        <TouchableOpacity 
          style={[styles.filterButton, { backgroundColor: themeColors.card }]}
          onPress={handleFilterPress}
        >
          <Filter size={20} color={themeColors.text} />
        </TouchableOpacity>
      </View>
      
      <SearchBar 
        placeholder="Search for recipes..."
        value={searchQuery}
        onChangeText={setSearchQuery}
        onSubmit={handleSearch}
        onVoiceSearch={() => console.log("Voice search")}
        onCameraSearch={() => console.log("Camera search")}
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            Meal Types
          </Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScroll}
          >
            {mealTypes.map((category) => (
              <CategoryPill 
                key={category.id}
                label={category.name}
                isSelected={selectedCategory === category.id}
                onPress={() => handleCategoryPress(category.id)}
              />
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            Cuisines
          </Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScroll}
          >
            {cuisines.map((cuisine) => (
              <CategoryPill 
                key={cuisine.id}
                label={cuisine.flag ? `${cuisine.flag} ${cuisine.name}` : cuisine.name}
                isSelected={selectedCategory === cuisine.id}
                onPress={() => handleCategoryPress(cuisine.id)}
              />
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            Dietary Preferences
          </Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScroll}
          >
            {dietaryTags.map((tag) => (
              <CategoryPill 
                key={tag.id}
                label={tag.name}
                isSelected={selectedCategory === tag.id}
                onPress={() => handleCategoryPress(tag.id)}
              />
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.recipesSection}>
          <Text style={[styles.sectionTitle, { color: themeColors.text }]}>
            Trending Now
          </Text>
          <View style={styles.recipesGrid}>
            {recipes.slice(0, 6).map((recipe) => (
              <View key={recipe.id} style={styles.recipeItem}>
                <RecipeCard recipe={recipe} />
              </View>
            ))}
          </View>
          
          <TouchableOpacity 
            style={[styles.viewAllButton, { borderColor: themeColors.border }]}
            onPress={() => router.push("/search")}
          >
            <Text style={[styles.viewAllText, { color: themeColors.primary }]}>
              View All Recipes
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 8,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
  },
  filterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 12,
    paddingHorizontal: 16,
  },
  categoriesScroll: {
    paddingHorizontal: 16,
    gap: 8,
  },
  recipesSection: {
    marginBottom: 32,
  },
  recipesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 12,
  },
  recipeItem: {
    width: "50%",
    paddingHorizontal: 4,
    marginBottom: 16,
  },
  viewAllButton: {
    marginHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
  },
  viewAllText: {
    fontSize: 16,
    fontWeight: "600",
  },
});