import React, { useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  Platform,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { colors } from "@/constants/colors";
import { useThemeStore } from "@/store/theme-store";
import { useUserStore } from "@/store/user-store";
import { ShoppingListItem } from "@/components/ui/ShoppingListItem";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Calendar, Plus, Share, Trash2 } from "lucide-react-native";
import * as Haptics from "expo-haptics";

export default function ShoppingScreen() {
  const router = useRouter();
  const activeTheme = useThemeStore(state => state.getActiveTheme());
  const themeColors = colors[activeTheme];
  
  const [newItemName, setNewItemName] = useState("");
  const [newItemAmount, setNewItemAmount] = useState("");
  const [newItemUnit, setNewItemUnit] = useState("");
  
  const { 
    shoppingList, 
    updateShoppingListItem, 
    removeFromShoppingList, 
    addToShoppingList,
    clearShoppingList,
    mealPlans,
  } = useUserStore();

  const handleToggleItem = (itemId: string) => {
    const item = shoppingList.find(item => item.id === itemId);
    if (item) {
      updateShoppingListItem(itemId, { checked: !item.checked });
    }
  };

  const handleDeleteItem = (itemId: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    if (Platform.OS === 'web') {
      if (confirm("Are you sure you want to remove this item?")) {
        removeFromShoppingList(itemId);
      }
    } else {
      Alert.alert(
        "Remove Item",
        "Are you sure you want to remove this item from your shopping list?",
        [
          { text: "Cancel", style: "cancel" },
          { 
            text: "Remove", 
            style: "destructive",
            onPress: () => removeFromShoppingList(itemId)
          }
        ]
      );
    }
  };

  const handleAddItem = () => {
    if (!newItemName.trim()) {
      if (Platform.OS === 'web') {
        alert("Please enter an item name");
      } else {
        Alert.alert("Error", "Please enter an item name");
      }
      return;
    }
    
    addToShoppingList({
      name: newItemName.trim(),
      amount: parseFloat(newItemAmount) || 1,
      unit: newItemUnit.trim() || "pcs",
      recipeId: "manual",
      recipeName: "Manual Entry",
      checked: false,
    });
    
    setNewItemName("");
    setNewItemAmount("");
    setNewItemUnit("");
    
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleClearList = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    if (shoppingList.length === 0) return;
    
    if (Platform.OS === 'web') {
      if (confirm("Are you sure you want to clear your entire shopping list?")) {
        clearShoppingList();
      }
    } else {
      Alert.alert(
        "Clear Shopping List",
        "Are you sure you want to clear your entire shopping list?",
        [
          { text: "Cancel", style: "cancel" },
          { 
            text: "Clear", 
            style: "destructive",
            onPress: () => clearShoppingList()
          }
        ]
      );
    }
  };

  const handleShareList = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    // Share functionality would be implemented here
    console.log("Share shopping list");
  };

  const handleViewMealPlan = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    router.push("/meal-plan-edit");
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: themeColors.background }]}>
      <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
      
      <View style={styles.header}>
        <Text style={[styles.title, { color: themeColors.text }]}>Shopping List</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity 
            style={[styles.iconButton, { backgroundColor: themeColors.card }]}
            onPress={handleShareList}
          >
            <Share size={20} color={themeColors.text} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.iconButton, { backgroundColor: themeColors.card }]}
            onPress={handleClearList}
          >
            <Trash2 size={20} color={themeColors.error} />
          </TouchableOpacity>
        </View>
      </View>
      
      <TouchableOpacity 
        style={[
          styles.mealPlanButton, 
          { 
            backgroundColor: themeColors.card,
            borderColor: themeColors.border,
          }
        ]}
        onPress={handleViewMealPlan}
      >
        <Calendar size={20} color={themeColors.primary} />
        <Text style={[styles.mealPlanText, { color: themeColors.text }]}>
          {mealPlans.length > 0 ? "View Meal Plan" : "Create Meal Plan"}
        </Text>
      </TouchableOpacity>
      
      <View style={styles.addItemContainer}>
        <View style={styles.addItemRow}>
          <View style={styles.itemNameInput}>
            <Input
              placeholder="Item name"
              value={newItemName}
              onChangeText={setNewItemName}
              containerStyle={styles.input}
            />
          </View>
          <View style={styles.itemAmountInput}>
            <Input
              placeholder="Qty"
              value={newItemAmount}
              onChangeText={setNewItemAmount}
              keyboardType="numeric"
              containerStyle={styles.input}
            />
          </View>
          <View style={styles.itemUnitInput}>
            <Input
              placeholder="Unit"
              value={newItemUnit}
              onChangeText={setNewItemUnit}
              containerStyle={styles.input}
            />
          </View>
        </View>
        <Button
          title="Add Item"
          onPress={handleAddItem}
          icon={<Plus size={16} color="white" />}
          fullWidth
        />
      </View>
      
      <FlatList
        data={shoppingList}
        renderItem={({ item }) => (
          <ShoppingListItem
            item={item}
            onToggle={() => handleToggleItem(item.id)}
            onDelete={() => handleDeleteItem(item.id)}
          />
        )}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyTitle, { color: themeColors.text }]}>
              Your shopping list is empty
            </Text>
            <Text style={[styles.emptyText, { color: themeColors.subtext }]}>
              Add items manually or from recipes
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 8,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
  },
  headerButtons: {
    flexDirection: "row",
    gap: 8,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  mealPlanButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 16,
    borderWidth: 1,
    gap: 8,
  },
  mealPlanText: {
    fontSize: 16,
    fontWeight: "500",
  },
  addItemContainer: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  addItemRow: {
    flexDirection: "row",
    marginBottom: 8,
    gap: 8,
  },
  itemNameInput: {
    flex: 2,
  },
  itemAmountInput: {
    flex: 1,
  },
  itemUnitInput: {
    flex: 1,
  },
  input: {
    marginBottom: 0,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
  },
});