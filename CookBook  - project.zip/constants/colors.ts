// Color palette for the app
export const colors = {
    light: {
      primary: '#FF7043', // Warm orange
      secondary: '#4CAF50', // Fresh green
      accent: '#FF9800', // Amber
      background: '#FFFFFF',
      card: '#F9F9F9',
      text: '#333333',
      subtext: '#757575',
      border: '#E0E0E0',
      success: '#4CAF50',
      error: '#F44336',
      warning: '#FFC107',
      info: '#2196F3',
      inactive: '#BDBDBD',
      highlight: '#FFF3E0',
    },
    dark: {
      primary: '#FF7043', // Warm orange
      secondary: '#66BB6A', // Fresh green
      accent: '#FFA726', // Amber
      background: '#121212',
      card: '#1E1E1E',
      text: '#FFFFFF',
      subtext: '#B0B0B0',
      border: '#333333',
      success: '#66BB6A',
      error: '#EF5350',
      warning: '#FFCA28',
      info: '#42A5F5',
      inactive: '#757575',
      highlight: '#3E2723',
    }
  };
  
  export const gradients = {
    primary: ['#FF7043', '#FF9800'],
    secondary: ['#4CAF50', '#8BC34A'],
    accent: ['#FF9800', '#FFEB3B'],
  };
  
  export default colors;