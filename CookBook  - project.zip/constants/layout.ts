import { Dimensions, Platform, PixelRatio, ScaledSize } from 'react-native';

// Initial dimensions
const { width: WINDOW_WIDTH, height: WINDOW_HEIGHT } = Dimensions.get('window');

// Base dimensions that design is created for
const baseWidth = 375; // iPhone X width
const baseHeight = 812; // iPhone X height

// Calculating scale factors
const widthScale = WINDOW_WIDTH / baseWidth;
const heightScale = WINDOW_HEIGHT / baseHeight;

// Use the smaller scale factor for consistent sizing
const scale = Math.min(widthScale, heightScale);

// Function to scale sizes based on device width
export function normalize(size: number): number {
  const newSize = size * scale;
  if (Platform.OS === 'ios') {
    return Math.round(PixelRatio.roundToNearestPixel(newSize));
  } else {
    return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2;
  }
}

// Function to handle responsive font sizes
export function responsiveFontSize(size: number): number {
  const newSize = size * scale;
  return Math.round(PixelRatio.roundToNearestPixel(newSize));
}

// Function to get responsive dimensions based on current screen size
export function getResponsiveDimensions() {
  const window = Dimensions.get('window');
  const isSmallDevice = window.width < 375;
  const isMediumDevice = window.width >= 375 && window.width < 768;
  const isLargeDevice = window.width >= 768;
  
  return {
    window,
    isSmallDevice,
    isMediumDevice,
    isLargeDevice,
  };
}

// Function to handle responsive spacing
export function getResponsiveSpacing() {
  const { isSmallDevice, isMediumDevice, isLargeDevice } = getResponsiveDimensions();
  
  return {
    xs: normalize(isSmallDevice ? 2 : 4),
    s: normalize(isSmallDevice ? 6 : 8),
    m: normalize(isSmallDevice ? 12 : isMediumDevice ? 16 : 20),
    l: normalize(isSmallDevice ? 18 : isMediumDevice ? 24 : 28),
    xl: normalize(isSmallDevice ? 24 : isMediumDevice ? 32 : 36),
    xxl: normalize(isSmallDevice ? 36 : isMediumDevice ? 48 : 56),
  };
}

// Function to handle responsive border radius
export function getResponsiveBorderRadius() {
  const { isSmallDevice, isMediumDevice } = getResponsiveDimensions();
  
  return {
    small: normalize(isSmallDevice ? 3 : 4),
    medium: normalize(isSmallDevice ? 6 : 8),
    large: normalize(isSmallDevice ? 9 : 12),
    xl: normalize(isSmallDevice ? 12 : 16),
    xxl: normalize(isSmallDevice ? 18 : 24),
    round: 9999,
  };
}

// Listen for dimension changes
Dimensions.addEventListener('change', () => {
  // This will update the dimensions when the device orientation changes
  const { width, height } = Dimensions.get('window');
  
  // Update global width and height
  Object.defineProperty(layout, 'window', {
    value: { width, height },
    writable: true,
  });
});

// Export default layout object with all responsive utilities
const layout = {
  window: {
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT,
  },
  isSmallDevice: WINDOW_WIDTH < 375,
  isMediumDevice: WINDOW_WIDTH >= 375 && WINDOW_WIDTH < 768,
  isLargeDevice: WINDOW_WIDTH >= 768,
  normalize,
  responsiveFontSize,
  getResponsiveDimensions,
  spacing: getResponsiveSpacing(),
  borderRadius: getResponsiveBorderRadius(),
};

export default layout;