import { Platform, NativeModules } from 'react-native';

export type Language = {
  id: string;
  name: string;
  nativeName: string;
  rtl?: boolean;
};

export const languages: Language[] = [
  { id: 'en', name: 'English', nativeName: 'English' },
  { id: 'es', name: 'Spanish', nativeName: 'Español' },
  { id: 'fr', name: 'French', nativeName: 'Français' },
  { id: 'de', name: 'German', nativeName: 'Deutsch' },
  { id: 'it', name: 'Italian', nativeName: 'Italiano' },
  { id: 'zh', name: 'Chinese', nativeName: '中文' },
  { id: 'ja', name: 'Japanese', nativeName: '日本語' },
  { id: 'ru', name: 'Russian', nativeName: 'Русский' },
  { id: 'ar', name: 'Arabic', nativeName: 'العربية', rtl: true },
  { id: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { id: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { id: 'nl', name: 'Dutch', nativeName: 'Nederlands' },
  { id: 'ko', name: 'Korean', nativeName: '한국어' },
  { id: 'tr', name: 'Turkish', nativeName: 'Türkçe' },
  { id: 'sv', name: 'Swedish', nativeName: 'Svenska' },
  { id: 'pl', name: 'Polish', nativeName: 'Polski' },
  { id: 'th', name: 'Thai', nativeName: 'ไทย' },
  { id: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { id: 'el', name: 'Greek', nativeName: 'Ελληνικά' },
  { id: 'he', name: 'Hebrew', nativeName: 'עברית', rtl: true },
  { id: 'uk', name: 'Ukrainian', nativeName: 'Українська' },
  { id: 'cs', name: 'Czech', nativeName: 'Čeština' },
  { id: 'da', name: 'Danish', nativeName: 'Dansk' },
  { id: 'fi', name: 'Finnish', nativeName: 'Suomi' },
  { id: 'hu', name: 'Hungarian', nativeName: 'Magyar' },
  { id: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
  { id: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu' },
  { id: 'no', name: 'Norwegian', nativeName: 'Norsk' },
  { id: 'ro', name: 'Romanian', nativeName: 'Română' },
  { id: 'sk', name: 'Slovak', nativeName: 'Slovenčina' },
];

// Get device language
export const getDeviceLanguage = (): string => {
  let deviceLanguage = 'en';
  
  try {
    if (Platform.OS === 'ios') {
      // For iOS
      const locale = 
        NativeModules.SettingsManager?.settings?.AppleLocale ||
        NativeModules.SettingsManager?.settings?.AppleLanguages?.[0] ||
        'en';
      
      deviceLanguage = locale.split('_')[0];
    } else if (Platform.OS === 'android') {
      // For Android
      const locale = NativeModules.I18nManager?.localeIdentifier || 
                    (NativeModules.SettingsManager && NativeModules.SettingsManager.settings && 
                     NativeModules.SettingsManager.settings.language) || 'en';
      deviceLanguage = locale.split('_')[0];
    } else {
      // For web or other platforms
      if (typeof navigator !== 'undefined' && navigator.language) {
        deviceLanguage = navigator.language.split('-')[0];
      }
    }
  } catch (error) {
    console.warn('Error detecting device language:', error);
    deviceLanguage = 'en';
  }
  
  // Check if device language is supported, otherwise default to English
  const isSupported = languages.some(lang => lang.id === deviceLanguage);
  return isSupported ? deviceLanguage : 'en';
};